# ================================================================
#    Style Engine UI Panel. Blender Python Script
# ================================================================

import bpy
import bpy.utils.previews
import shutil
from pathlib import Path
from . import utils
from . import workspace_setup

# Global preview collection for reference image thumbnails
# This persists across draw calls to avoid loading images repeatedly
preview_collections = {}

# Global cache for LoRa list to avoid repeated API calls
_lora_cache = {
    'items': [],
    'timestamp': 0,
    'cache_duration': 300  # 5 minutes
}


def _load_lora_ignore_list():
    """
    Load LoRa ignore list from loras/ignore.txt.
    Returns a set of patterns to exclude from dropdown.
    Supports both full paths and filenames.
    """
    from pathlib import Path
    
    try:
        addon_dir = Path(__file__).parent
        ignore_file = addon_dir / "loras" / "ignore.txt"
        
        print(f"[Style Engine] Looking for ignore list at: {ignore_file}")
        
        if not ignore_file.exists():
            print(f"[Style Engine] ignore.txt not found, no LoRAs will be filtered")
            return set()
        
        ignored = set()
        with open(ignore_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # Skip empty lines and comments
                if line and not line.startswith('#'):
                    # Add both the full path AND just the filename
                    # This handles both "file.safetensors" and "LoRAs/subfolder/file.safetensors"
                    ignored.add(line)  # Full path
                    filename = line.split('/')[-1]
                    ignored.add(filename)  # Just filename
        
        if ignored:
            print(f"[Style Engine] Loaded {len(ignored)} ignore patterns from ignore.txt")
        else:
            print(f"[Style Engine] ignore.txt is empty, no LoRAs filtered")
        
        return ignored
        
    except Exception as e:
        print(f"[Style Engine] ⚠️ Error loading ignore.txt: {e}")
        import traceback
        traceback.print_exc()
        return set()


def get_lora_items(self, context):
    """
    Dynamic callback to fetch available LoRa models from ComfyUI server.
    Caches results for 5 minutes to avoid excessive API calls.
    Filters out LoRAs listed in loras/ignore.txt.
    """
    import time
    from . import runcomfy_deployment
    
    # Check cache validity
    current_time = time.time()
    cache_age = current_time - _lora_cache['timestamp']
    
    # Default fallback items
    default_items = [
        ('NONE', "None", "No LoRa"),
        ('xl_more_art-full_v1.safetensors', "More Art Full", "Default LoRa"),
    ]
    
    # Return cached if valid
    if _lora_cache['items'] and cache_age < _lora_cache['cache_duration']:
        return _lora_cache['items']
    
    # Load ignore list
    ignored_loras = _load_lora_ignore_list()
    
    # Check if in GCS mode (self-hosted ComfyUI)
    try:
        prefs = context.preferences.addons['styleengine'].preferences
        
        if hasattr(prefs, 'api_backend') and prefs.api_backend == 'GCS':
            # Try to fetch from server
            try:
                server_client = runcomfy_deployment.get_server_client()
                
                # Fetch /object_info from ComfyUI server
                print("[Style Engine] Fetching LoRa list from ComfyUI server...")
                object_info = server_client._request('GET', '/object_info', timeout=5)
                
                if 'LoraLoader' in object_info:
                    lora_loader = object_info['LoraLoader']
                    
                    # Extract lora_name options: input.required.lora_name[0]
                    if 'input' in lora_loader and 'required' in lora_loader['input']:
                        lora_name_input = lora_loader['input']['required'].get('lora_name')
                        
                        if lora_name_input and isinstance(lora_name_input, list) and len(lora_name_input) > 0:
                            lora_list = lora_name_input[0]
                            
                            if isinstance(lora_list, list) and lora_list:
                                # Build items from server response
                                items = [('NONE', "None", "No LoRa")]
                                filtered_count = 0
                                
                                for lora_file in lora_list:
                                    # Skip if in ignore list
                                    if lora_file in ignored_loras:
                                        filtered_count += 1
                                        print(f"[Style Engine]   ✗ Filtered: {lora_file}")
                                        continue
                                    
                                    # Create readable display name
                                    display_name = lora_file.replace('.safetensors', '').replace('_', ' ').replace('-', ' ')
                                    display_name = ' '.join(word.capitalize() for word in display_name.split())
                                    
                                    # Truncate long names
                                    if len(display_name) > 35:
                                        display_name = display_name[:32] + "..."
                                    
                                    items.append((
                                        lora_file,           # Value: exact filename
                                        display_name,        # Display: readable name
                                        f"LoRa: {lora_file}" # Tooltip
                                    ))
                                
                                # Cache the results
                                _lora_cache['items'] = items
                                _lora_cache['timestamp'] = current_time
                                
                                print(f"[Style Engine] ✓ Found {len(items)-1} LoRa models on server ({filtered_count} filtered)")
                                return items
                
            except Exception as e:
                print(f"[Style Engine] ⚠️ Failed to fetch LoRas from server: {e}")
        
        # Fallback to default list
        print("[Style Engine] Using default LoRa list")
        return default_items
        
    except Exception as e:
        print(f"[Style Engine] Error in LoRa callback: {e}")
        return default_items

# ----------------------------------------------------------------
# 1. PROPERTY GROUP
# ----------------------------------------------------------------
class ObjectGroup(bpy.types.PropertyGroup):
    """Individual object group with keywords."""
    name: bpy.props.StringProperty(
        name="Group Name",
        default="NewGroup"
    )
    
    keywords: bpy.props.StringProperty(
        name="Keywords",
        default="",
        update=lambda self, context: context.scene.style_engine_props.update_session_json(context)
    )
    
    pass_index: bpy.props.IntProperty(
        name="Pass Index",
        default=12,
        min=1,
        max=32767
    )
    
    object_ids: bpy.props.StringProperty(
        name="Object IDs",
        description="Comma-separated list of object names",
        default=""
    )


class StyleEngineProperties(bpy.types.PropertyGroup):
    """Stores all the properties for the Style Engine panel."""
    
    def update_session_json(self, context):
        """Update session.json when any property changes."""
        from . import workspace_setup
        workspace_setup.write_session_json(context)

    library_id: bpy.props.StringProperty(
        name="Session ID",
        description="Unique identifier for this workflow session",
        default="session-0001",
        update=update_session_json
    )
    
    output_path: bpy.props.StringProperty(
        name="Output Path",
        description="Local directory to store renders and outputs (leave empty to use default)",
        default="",
        subtype='DIR_PATH',
        update=update_session_json
    )
    
    lookup: bpy.props.StringProperty(
        name="Lookup",
        description="RAG system lookup query",
        default="",
        update=update_session_json
    )

    global_prompt: bpy.props.StringProperty(
        name="Global Prompt",
        description="Master prompt for AI generation",
        default="",  # Start blank - user writes their own prompt
        update=update_session_json
    )
    
    negative_prompt: bpy.props.StringProperty(
        name="Negative Prompt",
        description="Negative prompt extracted from Prompt Builder",
        default="",
        update=update_session_json
    )
    
    show_workspace_setup: bpy.props.BoolProperty(
        name="Show Workspace Setup",
        description="Expand or collapse the workspace setup section",
        default=False
    )
    
    show_image_generation: bpy.props.BoolProperty(
        name="Show Image Generation",
        description="Expand or collapse the image generation section",
        default=False
    )
    
    show_settings: bpy.props.BoolProperty(
        name="Show Settings",
        description="Expand or collapse the settings section",
        default=False
    )
    
    # N Panel category dropdowns
    show_file_settings: bpy.props.BoolProperty(
        name="Show File Settings",
        description="Expand or collapse the File section",
        default=False
    )
    
    show_view_settings: bpy.props.BoolProperty(
        name="Show View Settings",
        description="Expand or collapse the View section",
        default=False
    )
    
    show_visualization: bpy.props.BoolProperty(
        name="Show Visualization",
        description="Expand or collapse the Visualization section",
        default=False
    )
    
    show_text_generation: bpy.props.BoolProperty(
        name="Show Text Generation",
        description="Expand or collapse the Text Generation section",
        default=False
    )
    
    show_image_generation_main: bpy.props.BoolProperty(
        name="Show Image Generation",
        description="Expand or collapse the Image Generation section",
        default=False
    )
    
    show_influence: bpy.props.BoolProperty(
        name="Show Influence",
        description="Expand or collapse the Influence section",
        default=False
    )
    
    show_reference_images: bpy.props.BoolProperty(
        name="Show Reference Images",
        description="Expand or collapse the Reference Images section",
        default=False
    )
    
    show_loras: bpy.props.BoolProperty(
        name="Show LoRas",
        description="Expand or collapse the LoRas section",
        default=False
    )
    
    show_3d_generation: bpy.props.BoolProperty(
        name="Show 3D Generation",
        description="Expand or collapse the 3D Generation section",
        default=False
    )
    
    show_3d_single_image: bpy.props.BoolProperty(
        name="Show 3D from Single Image",
        description="Expand or collapse the 3D from Single Image section",
        default=False
    )
    
    show_3d_multiview: bpy.props.BoolProperty(
        name="Show 3D from Multiview",
        description="Expand or collapse the 3D from Multiview section",
        default=False
    )
    
    show_groups: bpy.props.BoolProperty(
        name="Groups",
        description="Expand or collapse the groups section",
        default=False
    )

    active_group_index: bpy.props.IntProperty(
        name="Active Group Index",
        description="Currently selected group",
        default=0
    )
    
    # Dynamic groups collection
    object_groups: bpy.props.CollectionProperty(type=ObjectGroup)
    
    # Counter for generating unique group IDs
    group_counter: bpy.props.IntProperty(default=1)

    # Properties for the influence sliders (stored as 0-1, displayed as percentage)
    depth_influence: bpy.props.FloatProperty(
        name="Depth Influence",
        description="Controls the influence of depth (0.0 to 1.0)",
        default=0.5,
        min=0.0,
        max=1.0,
        update=update_session_json
    )

    silhouette_influence: bpy.props.FloatProperty(
        name="Silhouette Influence",
        description="Controls the strength of the silhouette (0.0 to 1.0)",
        default=0.5,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    texture_influence: bpy.props.FloatProperty(
        name="Viewport",
        description="Controls how much of the render to keep in img2img workflow (GCS mode). 1.0 = keep 100% of render, 0.0 = full AI generation ignoring render",
        default=0.0,
        min=0.0,
        max=1.0,  # UI shows 0-1, internally scaled to 0-0.7 when sent
        update=update_session_json
    )
    
    steps: bpy.props.IntProperty(
        name="Steps",
        description="Number of sampling steps for AI generation (15-30)",
        default=25,
        min=15,
        max=30,
        update=update_session_json
    )
    
    render_quality: bpy.props.EnumProperty(
        name="Render Quality",
        description="Quality of render sent to AI (affects img2img workflow)",
        items=[
            ('FAST', "Fast", "Workbench render - fast preview quality, good for quick iterations", 'SHADING_WIRE', 0),
            ('DETAILED', "Detailed", "EEVEE render - high quality, better for img2img when texture_influence is low", 'SHADING_RENDERED', 1),
        ],
        default='DETAILED',
        update=update_session_json
    )

    # Workspace settings
    def update_refresh_viewport(self, context):
        """
        Refresh viewport setting (now deprecated - always on-demand).
        Image refresh happens automatically when generation completes.
        This property is kept for compatibility but does nothing.
        """
        # No timer registration needed - refresh is on-demand via on_generation_complete
        if self.refresh_viewport:
            print("[Style Engine] Image refresh: on-demand (refreshes when generation completes)")
        else:
            print("[Style Engine] Note: Image refresh is always on-demand, no timer to disable")
    
    refresh_viewport: bpy.props.BoolProperty(
        name="Refresh Viewport",
        description="Automatically refresh AI image when it changes",
        default=True,
        update=update_refresh_viewport
    )
    
    def update_auto_generate(self, context):
        """Update auto-generate and sync refresh_viewport."""
        # Sync refresh_viewport with auto_generate
        self.refresh_viewport = self.auto_generate
        # Update session JSON
        self.update_session_json(context)
        
        # ✅ Start cyclical auto-generation if enabled
        if self.auto_generate:
            # Check if ai_camera exists
            if "ai_camera" not in bpy.data.objects:
                print("[Style Engine] ⚠️ Cannot start auto-generate: ai_camera not found!")
                print("[Style Engine] Please run 'Setup Workspace' first.")
                self.auto_generate = False  # Disable to prevent infinite errors
                return
            
            from . import workspace_setup
            print("[Style Engine] 🚀 Auto-generate enabled! Starting cyclical generation...")
            # Start the first generation cycle
            bpy.app.timers.register(workspace_setup.start_generation_cycle, first_interval=0.5)
        else:
            print("[Style Engine] Auto-generate disabled. Stopping cyclical generation.")
    
    auto_generate: bpy.props.BoolProperty(
        name="Autogenerate",
        description="Toggle continuous AI generation ON/OFF (when enabled, continuously renders and generates images)",
        default=False,
        update=update_auto_generate
    )
    
    # Prompt Builder - simple template-based prompt system
    def update_prompt_builder(self, context):
        """When Prompt Builder is enabled, auto-load templates"""
        # Update session.json
        self.update_session_json(context)
        
        # Auto-load templates when enabled
        if self.use_prompt_builder:
            from . import utils
            count, message = utils.load_all_templates()
            print(f"[Style Engine] Prompt Builder enabled: {message}")
            # Show info to user
            if context:
                context.area.tag_redraw() if hasattr(context, 'area') and context.area else None
    
    use_prompt_builder: bpy.props.BoolProperty(
        name="Enable Prompt Builder",
        description="Automatic: parses HTML tags if present, otherwise uses raw text",
        default=True,  # Always enabled by default
        update=update_prompt_builder
    )
    
    def update_background_opacity(self, context):
        """Update the ai_camera background image opacity."""
        if "ai_camera" in bpy.data.objects:
            ai_camera = bpy.data.objects["ai_camera"]
            cam_data = ai_camera.data
            
            # Update background images opacity
            for bg in cam_data.background_images:
                bg.alpha = self.background_opacity
                
            print(f"[Style Engine] Background opacity set to: {self.background_opacity:.2f}")
    
    background_opacity: bpy.props.FloatProperty(
        name="Background Opacity",
        description="Transparency of the AI background image (0=invisible, 1=opaque)",
        default=1.0,
        min=0.0,
        max=1.0,
        update=update_background_opacity
    )
    
    def update_visualization_type(self, context):
        """Switch camera background between Combined, Canny, and Depth visualizations."""
        from pathlib import Path
        from . import workspace_setup
        
        # Get temp directory
        temp_dir = workspace_setup.get_temp_directory(context)
        
        # Determine which image to display
        if self.visualization_type == 'COMBINED':
            image_path = temp_dir / "current_ai.png"
            display_name = "Combined (Final)"
        elif self.visualization_type == 'CANNY':
            image_path = temp_dir / "canny.png"
            display_name = "Silhouette (Canny)"
        elif self.visualization_type == 'DEPTH':
            image_path = temp_dir / "depth.png"
            display_name = "Depth Map"
        else:
            return
        
        # Check if file exists
        if not image_path.exists():
            print(f"[Visualization] ⚠️ {display_name} not found at {image_path}")
            print(f"[Visualization] Enable 'Download Preview Images' in preferences and generate an image first")
            return
        
        # Update camera background
        if "ai_camera" in bpy.data.objects:
            ai_camera = bpy.data.objects["ai_camera"]
            cam_data = ai_camera.data
            
            if cam_data.background_images:
                bg = cam_data.background_images[0]
                
                # Load or reload the image
                image_name = image_path.name
                if image_name in bpy.data.images:
                    img = bpy.data.images[image_name]
                    img.reload()
                else:
                    img = bpy.data.images.load(str(image_path))
                
                bg.image = img
                print(f"[Visualization] ✓ Switched to: {display_name}")
                
                # Force viewport update
                for area in context.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
        else:
            print(f"[Visualization] ⚠️ ai_camera not found. Setup workspace first.")
    
    visualization_type: bpy.props.EnumProperty(
        name="Visualization Type",
        description="Switch between different visualization modes",
        items=[
            ('COMBINED', "Combined", "Final generated image", 'IMAGE_DATA', 0),
            ('CANNY', "Silhouette", "Canny edge detection (what the AI sees as edges)", 'MESH_PLANE', 1),
            ('DEPTH', "Depth", "Depth map (what the AI sees as depth)", 'EMPTY_SINGLE_ARROW', 2),
        ],
        default='COMBINED',
        update=update_visualization_type
    )
    
    def update_ai_resolution(self, context):
        """
        ROCK SOLID: Update resolution immediately when user changes dropdown.
        This is CRITICAL - SDXL native resolutions directly influence output quality.
        Updates Blender's render settings, camera background, and session.json in real-time.
        """
        from . import workspace_setup
        
        try:
            # 1. Parse new resolution (SDXL native format)
            res_str = self.ai_resolution
            width, height = map(int, res_str.split('x'))
            
            # 2. Update Blender's render resolution IMMEDIATELY
            context.scene.render.resolution_x = width
            context.scene.render.resolution_y = height
            
            print(f"[Style Engine] ✓ Resolution set to: {width}x{height} (SDXL native)")
            
            # 3. Update camera background image if camera exists
            prefs = context.preferences.addons['styleengine'].preferences
            camera_name = prefs.camera_name_override
            
            if camera_name in bpy.data.objects:
                camera = bpy.data.objects[camera_name]
                if camera.type == 'CAMERA':
                    # Get temp directory
                    temp_dir = workspace_setup.get_temp_directory(context)
                    placeholder_path = temp_dir / "current_ai.png"
                    
                    # Resize existing image or create new placeholder
                    if "current_ai.png" in bpy.data.images:
                        img = bpy.data.images["current_ai.png"]
                        
                        # Check if image needs resizing
                        if img.size[0] != width or img.size[1] != height:
                            # Recreate image at new resolution
                            bpy.data.images.remove(img)
                            new_img = bpy.data.images.new("current_ai.png", width=width, height=height)
                            
                            # Fill with placeholder color (dark blue)
                            pixels = [0.1, 0.1, 0.2, 1.0] * (width * height)
                            new_img.pixels = pixels
                            
                            # Save to disk
                            new_img.filepath_raw = str(placeholder_path)
                            new_img.file_format = 'PNG'
                            new_img.save()
                            
                            # Update camera background reference
                            if len(camera.data.background_images) > 0:
                                bg_img = camera.data.background_images[0]
                                bg_img.image = new_img
                                
                                # Maintain opacity setting
                                bg_img.alpha = self.background_opacity
                                
                                print(f"[Style Engine] ✓ Camera background resized to {width}x{height}")
                    
                    # Force viewport redraw for immediate visual feedback
                    for area in context.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()
            
            # 4. Update session.json (critical for workflow JSON compatibility)
            workspace_setup.write_session_json(context)
            
        except Exception as e:
            print(f"[Style Engine] Error updating resolution: {e}")
            import traceback
            traceback.print_exc()
    
    ai_resolution: bpy.props.EnumProperty(
        name="AI Resolution",
        description="Resolution for AI generation (SDXL native resolutions - directly affects output quality)",
        items=[
            ('640x1536', '640 x 1536', 'Portrait tall'),
            ('768x1344', '768 x 1344', 'Portrait'),
            ('832x1216', '832 x 1216', 'Portrait medium'),
            ('896x1152', '896 x 1152', 'Portrait slight'),
            ('1024x1024', '1024 x 1024', 'Square'),
            ('1152x896', '1152 x 896', 'Landscape slight'),
            ('1216x832', '1216 x 832', 'Landscape medium'),
            ('1344x768', '1344 x 768', 'Landscape'),
            ('1536x640', '1536 x 640', 'Landscape wide'),
        ],
        default='1024x1024',
        update=update_ai_resolution  # Live, instant update - CRITICAL for SDXL workflow
    )
    
    save_iterations: bpy.props.BoolProperty(
        name="Save Iterations",
        description="Automatically save iteration snapshots with their corresponding AI images",
        default=True
    )
    
    # Generation browser - track current generation index
    current_generation_index: bpy.props.IntProperty(
        name="Current Generation",
        description="Index of currently displayed generation (0 = latest, -1 = newest)",
        default=-1,  # -1 means "latest/newest"
        min=-1
    )
    
    # Prompt browser - track current prompt index
    current_prompt_index: bpy.props.IntProperty(
        name="Current Prompt",
        description="Index of currently displayed prompt snapshot (0 = oldest, -1 = latest)",
        default=-1,  # -1 means "latest/newest"
        min=-1
    )
    
    # Model browser - track current model index
    current_model_index: bpy.props.IntProperty(
        name="Current Model",
        description="Index of currently selected model (0 = oldest, -1 = latest)",
        default=-1,  # -1 means "latest/newest"
        min=-1
    )
    
    # ================================================================
    # REFERENCE IMAGE SYSTEM (15 slots: 5 per mode)
    # ================================================================
    
    # Collapsible sections for reference modes
    show_style_transfer: bpy.props.BoolProperty(
        name="Show Style Transfer",
        description="Expand or collapse the Style Transfer section",
        default=False
    )
    
    show_composition: bpy.props.BoolProperty(
        name="Show Composition",
        description="Expand or collapse the Composition section",
        default=False
    )
    
    show_force_transfer: bpy.props.BoolProperty(
        name="Show Force Style Transfer",
        description="Expand or collapse the Force Style Transfer section",
        default=False
    )
    
    # Advanced control toggle for reference images
    show_advanced_ref_controls: bpy.props.BoolProperty(
        name="Advanced Control",
        description="Show individual weight sliders for each reference image (default: all weights = 1.0)",
        default=False
    )
    
    # Global strength sliders (UI: 0.0-1.0, Workflow: 0.0-1.5 via 1.5x multiplier)
    style_transfer_strength: bpy.props.FloatProperty(
        name="Style Transfer Strength",
        description="Global strength for all Style Transfer images (0.0 to 1.0, scaled to 1.5 in workflow)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    composition_strength: bpy.props.FloatProperty(
        name="Composition Strength",
        description="Global strength for all Composition images (0.0 to 1.0, scaled to 1.5 in workflow)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    force_transfer_strength: bpy.props.FloatProperty(
        name="Force Style Transfer Strength",
        description="Global strength for all Force Style Transfer images (0.0 to 5.0)",
        default=0.0,
        min=0.0,
        max=5.0,
        update=update_session_json
    )
    
    # Style Transfer images (ST1-ST5)
    st1_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Style Transfer 1"
    )
    st1_weight: bpy.props.FloatProperty(
        name="ST1 Weight",
        description="Individual weight for Style Transfer image 1 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    st2_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Style Transfer 2"
    )
    st2_weight: bpy.props.FloatProperty(
        name="ST2 Weight",
        description="Individual weight for Style Transfer image 2 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    st3_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Style Transfer 3"
    )
    st3_weight: bpy.props.FloatProperty(
        name="ST3 Weight",
        description="Individual weight for Style Transfer image 3 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    st4_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Style Transfer 4"
    )
    st4_weight: bpy.props.FloatProperty(
        name="ST4 Weight",
        description="Individual weight for Style Transfer image 4 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    st5_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Style Transfer 5"
    )
    st5_weight: bpy.props.FloatProperty(
        name="ST5 Weight",
        description="Individual weight for Style Transfer image 5 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    # Composition images (COMP1-COMP5)
    comp1_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Composition 1"
    )
    comp1_weight: bpy.props.FloatProperty(
        name="COMP1 Weight",
        description="Individual weight for Composition image 1 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    comp2_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Composition 2"
    )
    comp2_weight: bpy.props.FloatProperty(
        name="COMP2 Weight",
        description="Individual weight for Composition image 2 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    comp3_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Composition 3"
    )
    comp3_weight: bpy.props.FloatProperty(
        name="COMP3 Weight",
        description="Individual weight for Composition image 3 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    comp4_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Composition 4"
    )
    comp4_weight: bpy.props.FloatProperty(
        name="COMP4 Weight",
        description="Individual weight for Composition image 4 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    comp5_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Composition 5"
    )
    comp5_weight: bpy.props.FloatProperty(
        name="COMP5 Weight",
        description="Individual weight for Composition image 5 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    # Force Style Transfer images (SST1-SST5)
    sst1_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Force Style Transfer 1"
    )
    sst1_weight: bpy.props.FloatProperty(
        name="SST1 Weight",
        description="Individual weight for Force Style Transfer image 1 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    sst2_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Force Style Transfer 2"
    )
    sst2_weight: bpy.props.FloatProperty(
        name="SST2 Weight",
        description="Individual weight for Force Style Transfer image 2 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    sst3_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Force Style Transfer 3"
    )
    sst3_weight: bpy.props.FloatProperty(
        name="SST3 Weight",
        description="Individual weight for Force Style Transfer image 3 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    sst4_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Force Style Transfer 4"
    )
    sst4_weight: bpy.props.FloatProperty(
        name="SST4 Weight",
        description="Individual weight for Force Style Transfer image 4 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    sst5_image: bpy.props.PointerProperty(
        type=bpy.types.Image,
        name="Force Style Transfer 5"
    )
    sst5_weight: bpy.props.FloatProperty(
        name="SST5 Weight",
        description="Individual weight for Force Style Transfer image 5 (0.0 to 1.0)",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_session_json
    )
    
    # IPAdapter properties
    show_ipadapter: bpy.props.BoolProperty(
        name="Show IPAdapter",
        description="Expand or collapse the IPAdapter section",
        default=False
    )
    
    use_ipadapter: bpy.props.BoolProperty(
        name="Use image reference",
        description="Enable IPAdapter workflow with reference image guidance",
        default=False,
        update=update_session_json
    )
    
    ipadapter_reference_image: bpy.props.StringProperty(
        name="Reference Image",
        description="Path to reference image for style/composition guidance",
        default="",
        subtype='FILE_PATH',
        update=update_session_json
    )
    
    ipadapter_weight_type: bpy.props.EnumProperty(
        name="Mode",
        description="IPAdapter application mode",
        items=[
            ('style transfer', "Style Transfer", 
             "Apply artistic style from reference image"),
            ('composition', "Composition", 
             "Use reference for layout and structure"),
            ('strong style transfer', "Strong Style Transfer", 
             "Aggressive style application")
        ],
        default='style transfer',
        update=update_session_json
    )
    
    ipadapter_strength: bpy.props.FloatProperty(
        name="Strength",
        description="IPAdapter influence (0.0=off, 5.0=maximum)",
        default=0.75,
        min=0.0,
        max=5.0,
        step=5,
        precision=2,
        update=update_session_json
    )
    
    # ================================================================
    # LORA CONFIGURATION
    # ================================================================
    
    lora_enabled: bpy.props.BoolProperty(
        name="Use LoRa",
        description="Enable LoRa model for generation",
        default=False,
        update=update_session_json
    )
    
    lora_name: bpy.props.EnumProperty(
        name="LoRa Model",
        description="Select LoRa model to use (fetched from ComfyUI server in GCS mode)",
        items=get_lora_items,  # Dynamic callback - fetches from server
        update=update_session_json
    )
    
    lora_strength_model: bpy.props.FloatProperty(
        name="LoRa Strength",
        description="LoRa influence on the model (0.0 to 1.0)",
        default=0.8,
        min=0.0,
        max=1.0,
        step=1,
        precision=2,
        update=update_session_json
    )
    
    # LoRa 2 (second LoRa slot for stacking)
    lora2_enabled: bpy.props.BoolProperty(
        name="Use LoRa 2",
        description="Enable second LoRa model for stacking effects",
        default=False,
        update=update_session_json
    )
    
    lora2_name: bpy.props.EnumProperty(
        name="LoRa 2 Model",
        description="Select second LoRa model (fetched from ComfyUI server in GCS mode)",
        items=get_lora_items,  # Dynamic callback - fetches from server
        update=update_session_json
    )
    
    lora2_strength_model: bpy.props.FloatProperty(
        name="LoRa 2 Strength",
        description="Second LoRa influence on the model (0.0 to 1.0)",
        default=0.8,
        min=0.0,
        max=1.0,
        step=1,
        precision=2,
        update=update_session_json
    )
    
    # ================================================================
    # 3D OBJECT GENERATION CONFIGURATION
    # ================================================================
    
    object_quality: bpy.props.EnumProperty(
        name="3D Quality",
        description="Generation quality preset for 3D object creation",
        items=[
            ('SKETCH', "Sketch", "Ultra-fast preview - Lowest detail for concept testing"),
            ('FAST', "Fast", "Quick preview - Draft quality for rapid iteration"),
            ('BALANCED', "Balanced", "Production quality - Recommended for most work"),
            ('DETAILED', "Detailed", "Maximum detail - Ultra-high quality for hero assets"),
        ],
        default='BALANCED',
        update=update_session_json
    )


# ----------------------------------------------------------------
# 2. OPERATORS
# ----------------------------------------------------------------
# Legacy operators removed - no longer needed


class WM_OT_AlignAICameraToView(bpy.types.Operator):
    """Align AI camera to current 3D viewport."""
    bl_idname = "style_engine.align_camera_to_view"
    bl_label = "Reposition AI Camera"
    bl_description = "Move AI camera to match current 3D viewport view (like Ctrl+Alt+Numpad0)"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        prefs = context.preferences.addons['styleengine'].preferences
        camera_name = prefs.camera_name_override
        
        # Find ai_camera
        if camera_name not in bpy.data.objects:
            self.report({'ERROR'}, f"Camera '{camera_name}' not found. Run 'Setup Workspace' first.")
            return {'CANCELLED'}
        
        ai_camera = bpy.data.objects[camera_name]
        
        if ai_camera.type != 'CAMERA':
            self.report({'ERROR'}, f"'{camera_name}' is not a camera!")
            return {'CANCELLED'}
        
        # Find active 3D viewport
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        # Get current view matrix
                        view_matrix = space.region_3d.view_matrix.inverted()
                        
                        # Align camera to view
                        ai_camera.matrix_world = view_matrix
                        
                        self.report({'INFO'}, "AI camera repositioned to current view")
                        
                        if prefs.debug_mode:
                            print(f"[Style Engine] ✓ Camera '{camera_name}' aligned to view")
                            print(f"[Style Engine]   Location: {ai_camera.location}")
                        
                        return {'FINISHED'}
        
        self.report({'WARNING'}, "No 3D viewport found")
        return {'CANCELLED'}


class WM_OT_BringBackgroundForward(bpy.types.Operator):
    """Bring AI background image in front of objects"""
    bl_idname = "style_engine.bring_background_forward"
    bl_label = "Bring Forward"
    bl_description = "Display AI background image in front of 3D objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        prefs = context.preferences.addons['styleengine'].preferences
        camera_name = prefs.camera_name_override
        
        if camera_name not in bpy.data.objects:
            self.report({'WARNING'}, f"Camera '{camera_name}' not found")
            return {'CANCELLED'}
        
        ai_camera = bpy.data.objects[camera_name]
        if ai_camera.type != 'CAMERA':
            self.report({'WARNING'}, f"'{camera_name}' is not a camera")
            return {'CANCELLED'}
        
        cam_data = ai_camera.data
        if len(cam_data.background_images) > 0:
            cam_data.background_images[0].display_depth = 'FRONT'
            self.report({'INFO'}, "Background image brought forward")
            print("[Style Engine] ✓ Background display_depth: FRONT (in front of objects)")
            
            # Redraw viewports
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
            
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "No background image found on camera")
            return {'CANCELLED'}


class WM_OT_SendBackgroundBack(bpy.types.Operator):
    """Send AI background image behind objects"""
    bl_idname = "style_engine.send_background_back"
    bl_label = "Send to Back"
    bl_description = "Display AI background image behind 3D objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        prefs = context.preferences.addons['styleengine'].preferences
        camera_name = prefs.camera_name_override
        
        if camera_name not in bpy.data.objects:
            self.report({'WARNING'}, f"Camera '{camera_name}' not found")
            return {'CANCELLED'}
        
        ai_camera = bpy.data.objects[camera_name]
        if ai_camera.type != 'CAMERA':
            self.report({'WARNING'}, f"'{camera_name}' is not a camera")
            return {'CANCELLED'}
        
        cam_data = ai_camera.data
        if len(cam_data.background_images) > 0:
            cam_data.background_images[0].display_depth = 'BACK'
            self.report({'INFO'}, "Background image sent to back")
            print("[Style Engine] ✓ Background display_depth: BACK (behind objects)")
            
            # Redraw viewports
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
            
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "No background image found on camera")
            return {'CANCELLED'}


# Prompt editor operators removed - text editor now auto-created in workspace layout
# and auto-syncs on generation (no manual buttons needed)


class WM_OT_AddGroup(bpy.types.Operator):
    """Add a new object group."""
    bl_idname = "style_engine.add_group"
    bl_label = "Add Group"
    
    group_name: bpy.props.StringProperty(
        name="Group Name",
        default="NewGroup"
    )
    
    def invoke(self, context, event):
        # Show popup dialog for name input
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "group_name")
    
    def execute(self, context):
        props = context.scene.style_engine_props
        
        # Create new group
        new_group = props.object_groups.add()
        new_group.name = self.group_name if self.group_name else f"Group_{props.group_counter}"
        new_group.keywords = ""
        new_group.pass_index = 12 + len(props.object_groups) - 1  # Unique pass index
        new_group.object_ids = ""
        
        # Increment counter
        props.group_counter += 1
        
        # Set as active
        props.active_group_index = len(props.object_groups) - 1
        
        # Update session JSON
        from . import workspace_setup
        workspace_setup.write_session_json(context)
        
        self.report({'INFO'}, f"Created group: {new_group.name}")
        print(f"[Style Engine] Created group: {new_group.name}")
        
        return {'FINISHED'}


class WM_OT_AssignGroup(bpy.types.Operator):
    """Assign selected objects to active group."""
    bl_idname = "style_engine.assign_group"
    bl_label = "Assign to Group"
    
    def execute(self, context):
        # Placeholder - will assign selected objects to group
        selected = [obj.name for obj in context.selected_objects]
        self.report({'INFO'}, f"Assign - Selected: {len(selected)} objects")
        print(f"[Style Engine] Assign Group clicked - {selected}")
        return {'FINISHED'}


class WM_OT_RenameGroup(bpy.types.Operator):
    """Rename the active group."""
    bl_idname = "style_engine.rename_group"
    bl_label = "Rename Group"
    
    def execute(self, context):
        # Placeholder - will open rename dialog
        self.report({'INFO'}, "Rename Group - Coming soon")
        print("[Style Engine] Rename Group clicked")
        return {'FINISHED'}


class WM_OT_SelectGroup(bpy.types.Operator):
    """Select a group to make it active."""
    bl_idname = "style_engine.select_group"
    bl_label = "Select Group"
    
    group_index: bpy.props.IntProperty()
    
    def execute(self, context):
        props = context.scene.style_engine_props
        props.active_group_index = self.group_index
        
        group_names = ["BUILDINGS", "TUNNELS", "GROUND"]
        if self.group_index < len(group_names):
            print(f"[Style Engine] Selected group: {group_names[self.group_index]}")
        
        return {'FINISHED'}


class WM_OT_DeleteGroup(bpy.types.Operator):
    """Delete the active group."""
    bl_idname = "style_engine.delete_group"
    bl_label = "Delete Group"
    
    def execute(self, context):
        props = context.scene.style_engine_props
        active = props.active_group_index
        
        if 0 <= active < len(props.object_groups):
            group_name = props.object_groups[active].name
            props.object_groups.remove(active)
            
            # Adjust active index if needed
            if props.active_group_index >= len(props.object_groups):
                props.active_group_index = max(0, len(props.object_groups) - 1)
            
            # Update session JSON
            from . import workspace_setup
            workspace_setup.write_session_json(context)
            
            self.report({'INFO'}, f"Deleted group: {group_name}")
            print(f"[Style Engine] Deleted group: {group_name}")
        else:
            self.report({'WARNING'}, "No group selected")
        
        return {'FINISHED'}


class WM_OT_ProjectTexture(bpy.types.Operator):
    """Project AI texture onto selected objects from camera view."""
    bl_idname = "style_engine.project_texture"
    bl_label = "Project Texture"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Check if ai_camera exists
        if "ai_camera" not in bpy.data.objects:
            self.report({'ERROR'}, "AI Camera not found. Please setup workspace first.")
            return {'CANCELLED'}
        
        ai_camera = bpy.data.objects["ai_camera"]
        
        # Get path to current_ai.png using the correct temp directory
        from . import workspace_setup
        temp_dir = workspace_setup.get_temp_directory(context)
        img_path = temp_dir / "current_ai.png"
        
        print(f"[Style Engine] Looking for AI image at: {img_path}")
        
        if not img_path.exists():
            self.report({'ERROR'}, f"AI image not found at {img_path}. Generate an image first.")
            return {'CANCELLED'}
        
        print(f"[Style Engine] Found image, loading for projection...")
        
        # Load or reload the image
        img_name = "current_ai.png"
        if img_name in bpy.data.images:
            img = bpy.data.images[img_name]
            img.filepath = str(img_path)
            img.reload()
        else:
            img = bpy.data.images.load(str(img_path))
            img.name = img_name
        
        # Store original state
        original_active = context.view_layer.objects.active
        original_selected = list(context.selected_objects)
        original_mode = context.object.mode if context.object else 'OBJECT'
        original_camera = context.scene.camera
        
        # Temporarily set ai_camera as scene camera for projection
        context.scene.camera = ai_camera
        
        # Make sure we're in object mode
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Get only selected mesh objects (changed from all scene objects)
        mesh_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if not mesh_objects:
            self.report({'WARNING'}, "No mesh objects selected. Please select objects to project texture onto.")
            return {'CANCELLED'}
        
        # Find next iteration number for unique material/image naming
        iteration_num = 0
        while f"iteration_{iteration_num:03d}" in bpy.data.materials:
            iteration_num += 1
        
        iteration_name = f"iteration_{iteration_num:03d}"
        
        # Duplicate the current_ai.png image to create an archival copy
        # This ensures the texture won't change when new AI images are generated
        img_copy = img.copy()
        img_copy.name = f"{iteration_name}.png"
        
        # Pack the image so it's embedded in the .blend file
        if not img_copy.packed_file:
            img_copy.pack()
        
        print(f"[Style Engine] 📸 Created archival image: {img_copy.name}")
        
        # Save texture to project library iterations folder (external backup)
        self.save_iteration_texture(context, img_path, iteration_name)
        
        # Create a new unique material for this iteration
        mat = bpy.data.materials.new(name=iteration_name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        # Clear default nodes
        nodes.clear()
        
        # Create Principled BSDF
        bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
        bsdf.location = (0, 0)
        
        # Set roughness to 1.0 for matte finish
        bsdf.inputs['Roughness'].default_value = 1.0
        
        # Create Image Texture node with the duplicated image
        tex_node = nodes.new(type='ShaderNodeTexImage')
        tex_node.location = (-300, 0)
        tex_node.image = img_copy  # Use the duplicated image, not the original
        
        # Create Material Output
        output = nodes.new(type='ShaderNodeOutputMaterial')
        output.location = (300, 0)
        
        # Connect nodes
        # Connect texture to Base Color
        links.new(tex_node.outputs['Color'], bsdf.inputs['Base Color'])
        
        # Connect texture to Specular Tint to prevent white/washed out IOR look
        # This tints the specular reflections and refractions with the texture color
        if 'Specular Tint' in bsdf.inputs:
            links.new(tex_node.outputs['Color'], bsdf.inputs['Specular Tint'])
        
        # Connect BSDF to output
        links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        
        print(f"[Style Engine] 🎨 Created archival material: {mat.name}")
        
        # Simple projection: Project from active view onto all selected objects at once
        projected_count = 0
        
        try:
            # Assign material to all selected objects
            for obj in mesh_objects:
                if len(obj.data.materials) == 0:
                    obj.data.materials.append(mat)
                else:
                    obj.data.materials[0] = mat
                projected_count += 1
                print(f"[Style Engine] ✓ Assigned material to {obj.name}")
            
            # Enter edit mode (works with all selected objects)
            bpy.ops.object.mode_set(mode='EDIT')
            
            # Select all faces
            bpy.ops.mesh.select_all(action='SELECT')
            
            # Find 3D viewport and temporarily switch to camera view for projection
            viewport_3d = None
            space_3d = None
            original_view_perspective = None
            
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    viewport_3d = area
                    for space in area.spaces:
                        if space.type == 'VIEW_3D':
                            space_3d = space
                            original_view_perspective = space.region_3d.view_perspective
                            break
                    break
            
            if space_3d and original_view_perspective:
                # Temporarily switch to camera view
                space_3d.region_3d.view_perspective = 'CAMERA'
                print(f"[Style Engine] Temporarily switched viewport to camera view for projection")
            
            # Project from ai_camera (matches the texture that was rendered from this camera)
            bpy.ops.uv.project_from_view(
                camera_bounds=True,  # Use camera projection bounds
                correct_aspect=True,
                scale_to_bounds=False
            )
            
            # Restore original viewport perspective
            if space_3d and original_view_perspective:
                space_3d.region_3d.view_perspective = original_view_perspective
                print(f"[Style Engine] Restored viewport to original view")
            
            # Return to object mode
            bpy.ops.object.mode_set(mode='OBJECT')
            
            print(f"[Style Engine] ✓ Projected texture from ai_camera onto {projected_count} objects")
            
        except Exception as e:
            print(f"[Style Engine] ✗ Error during projection: {e}")
            
            # Restore viewport perspective if it was changed
            if 'space_3d' in locals() and space_3d and 'original_view_perspective' in locals() and original_view_perspective:
                try:
                    space_3d.region_3d.view_perspective = original_view_perspective
                    print(f"[Style Engine] Restored viewport after error")
                except:
                    pass
            
            # Make sure we're back in object mode
            if context.object and context.object.mode != 'OBJECT':
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                except:
                    pass
        
        # Restore original camera
        context.scene.camera = original_camera
        
        # Restore original selection
        for o in context.selected_objects:
            o.select_set(False)
        for obj in original_selected:
            if obj.name in context.scene.objects:
                obj.select_set(True)
        
        if original_active and original_active.name in context.scene.objects:
            context.view_layer.objects.active = original_active
        
        # Restore original mode
        if original_mode == 'EDIT':
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except:
                pass
        
        self.report({'INFO'}, f"Projected {iteration_name} onto {projected_count} objects")
        print(f"[Style Engine] 🎨 Projected {iteration_name} onto {projected_count} objects")
        
        # Create iteration snapshot
        self.create_iteration_snapshot(context, mesh_objects)
        
        return {'FINISHED'}
    
    def save_iteration_texture(self, context, source_image_path, iteration_name):
        """
        Save iteration texture to project library iterations folder.
        Provides external backup of projected textures.
        
        Args:
            context: Blender context
            source_image_path: Path to current_ai.png
            iteration_name: Name like 'iteration_000'
        """
        from . import workspace_setup
        from pathlib import Path
        import shutil
        
        # Get project library
        project_lib = workspace_setup.get_project_library(context)
        
        if project_lib:
            # Save to project library Textures folder
            textures_dir = project_lib / "Textures"
            textures_dir.mkdir(parents=True, exist_ok=True)
            
            dest_path = textures_dir / f"{iteration_name}.png"
            
            try:
                shutil.copy2(source_image_path, dest_path)
                print(f"[Style Engine] 💾 Saved texture to: {dest_path.name}")
            except Exception as e:
                print(f"[Style Engine] ⚠️ Failed to save texture to Textures folder: {e}")
        else:
            # .blend not saved - save to session temp
            import tempfile
            session_id = workspace_setup.get_session_id()
            temp_base = Path(tempfile.gettempdir()) / "blender_styleengine" / "sessions"
            textures_dir = temp_base / session_id / "Textures"
            textures_dir.mkdir(parents=True, exist_ok=True)
            
            dest_path = textures_dir / f"{iteration_name}.png"
            
            try:
                shutil.copy2(source_image_path, dest_path)
                print(f"[Style Engine] 💾 Saved texture to session: {dest_path.name}")
                print(f"[Style Engine] ℹ️  Save .blend to migrate to project library")
            except Exception as e:
                print(f"[Style Engine] ⚠️ Failed to save texture: {e}")
    
    def create_iteration_snapshot(self, context, mesh_objects):
        """Create a snapshot of all meshes joined into a single iteration object."""
        if not mesh_objects:
            return
        
        props = context.scene.style_engine_props
        
        # Check if save iterations is enabled
        if not props.save_iterations:
            print("[Style Engine] ⏭️ Save Iterations disabled, skipping snapshot")
            return
        
        # Ensure we're in object mode
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Get or create "Iterations" collection
        if "Iterations" not in bpy.data.collections:
            iterations_collection = bpy.data.collections.new("Iterations")
            context.scene.collection.children.link(iterations_collection)
            print("[Style Engine] Created 'Iterations' collection")
        else:
            iterations_collection = bpy.data.collections["Iterations"]
        
        # Find next iteration number
        iteration_num = 0
        while f"Iteration_{iteration_num:03d}" in bpy.data.objects:
            iteration_num += 1
        
        iteration_name = f"Iteration_{iteration_num:03d}"
        
        # Deselect all
        for obj in context.selected_objects:
            obj.select_set(False)
        
        # Select all mesh objects
        for obj in mesh_objects:
            obj.select_set(True)
        
        # Set one as active for duplication
        if mesh_objects:
            context.view_layer.objects.active = mesh_objects[0]
        
        # Get current objects before duplication
        objects_before = set(bpy.data.objects)
        
        # Duplicate all selected objects at once
        bpy.ops.object.duplicate(linked=False)
        
        # Find the new duplicated objects
        objects_after = set(bpy.data.objects)
        duplicates = list(objects_after - objects_before)
        
        print(f"[Style Engine] 📦 Duplicated {len(duplicates)} objects")
        
        # Deselect originals, keep duplicates selected
        for obj in mesh_objects:
            obj.select_set(False)
        
        # Set one as active
        if duplicates:
            context.view_layer.objects.active = duplicates[0]
            
            # Join all duplicates into one mesh (Ctrl+J equivalent)
            if len(duplicates) > 1:
                bpy.ops.object.join()
            
            # Get the joined object (active object after join)
            joined_obj = context.active_object
            
            # Rename it
            joined_obj.name = iteration_name
            
            # Unlink from current collection and link to Iterations collection
            for coll in joined_obj.users_collection:
                coll.objects.unlink(joined_obj)
            iterations_collection.objects.link(joined_obj)
            
            # Hide from viewport (eye icon in outliner)
            joined_obj.hide_viewport = True
            
            # Disable in renders (camera icon)
            joined_obj.hide_render = True
            
            # Ensure object is not "disabled" (gray font) - keep it selectable
            joined_obj.hide_select = False
            
            # Deselect
            joined_obj.select_set(False)
            
            print(f"[Style Engine] 💾 Created {iteration_name} in Iterations collection")
            print(f"[Style Engine]    └─ Hidden from viewport (eye icon) and disabled in renders")
            
            # Copy AI image to generated folder and assign material
            self.save_iteration_image_and_material(iteration_name, joined_obj)
    
    def save_iteration_image_and_material(self, iteration_name, obj):
        """Copy the AI image and assign it as the base color material."""
        try:
            # Get project root (go up from addon root)
            addon_root = Path(__file__).parent.parent.parent.parent
            
            # Path to current AI image
            ai_image_path = addon_root / "data" / "temp" / "ai_vision" / "current_ai.png"
            
            if not ai_image_path.exists():
                print(f"[Style Engine] ⚠️ AI image not found at {ai_image_path}")
                return
            
            # Create generated folder if it doesn't exist
            generated_folder = addon_root / "generated"
            generated_folder.mkdir(exist_ok=True)
            
            # Copy image to generated folder with iteration name
            dest_image_path = generated_folder / f"{iteration_name}.png"
            shutil.copy2(ai_image_path, dest_image_path)
            print(f"[Style Engine] 📸 Saved image: {dest_image_path.name}")
            
            # Load the image into Blender
            if iteration_name in bpy.data.images:
                bpy.data.images.remove(bpy.data.images[iteration_name])
            
            img = bpy.data.images.load(str(dest_image_path))
            img.name = iteration_name
            
            # Create or get material
            mat_name = f"{iteration_name}_Material"
            if mat_name in bpy.data.materials:
                mat = bpy.data.materials[mat_name]
            else:
                mat = bpy.data.materials.new(name=mat_name)
                mat.use_nodes = True
            
            # Clear existing nodes and create new setup
            nodes = mat.node_tree.nodes
            nodes.clear()
            
            # Create nodes
            output_node = nodes.new(type='ShaderNodeOutputMaterial')
            output_node.location = (300, 0)
            
            bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')
            bsdf_node.location = (0, 0)
            
            tex_node = nodes.new(type='ShaderNodeTexImage')
            tex_node.location = (-300, 0)
            tex_node.image = img
            
            # Connect nodes
            links = mat.node_tree.links
            links.new(tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])
            links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
            
            # Assign material to object
            if obj.data.materials:
                obj.data.materials[0] = mat
            else:
                obj.data.materials.append(mat)
            
            print(f"[Style Engine] 🎨 Material '{mat_name}' assigned with texture")
            
        except Exception as e:
            print(f"[Style Engine] ❌ Error saving iteration image/material: {e}")


# ================================================================
# PBR FROM PROJECTED TEXTURE OPERATOR
# ================================================================

class WM_OT_PBRFromProjectedTexture(bpy.types.Operator):
    """Generate PBR material maps from a projected iteration texture using chord_v1"""
    bl_idname = "style_engine.pbr_from_projected"
    bl_label = "PBR from Projected Texture"
    bl_description = "Generate PBR maps (basecolor, normal, roughness, metalness) from the projected texture"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        import json
        import re
        from pathlib import Path
        from . import runcomfy_deployment
        from . import workspace_setup
        from . import progress_bar
        from . import runcomfy_polling
        from .runcomfy_server_client import extract_output_images
        
        # 1. Validate: active object must have an iteration material
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.materials:
            self.report({'ERROR'}, "Select a mesh with a projected iteration texture")
            return {'CANCELLED'}
        
        # Find the HIGHEST numbered iteration material on this object
        # This ensures we process newest first: iteration_002 before iteration_001
        best_slot = -1
        best_num = -1
        iteration_mat = None
        for slot_idx, mat in enumerate(obj.data.materials):
            if mat and mat.name.startswith('iteration_'):
                m = re.match(r'iteration_(\d+)', mat.name)
                if m:
                    num = int(m.group(1))
                    if num > best_num:
                        best_num = num
                        best_slot = slot_idx
                        iteration_mat = mat
        
        if not iteration_mat or best_slot < 0:
            self.report({'ERROR'}, "Selected object has no iteration_XXX material")
            return {'CANCELLED'}
        
        iter_num = f"{best_num:03d}"
        print(f"[PBR] Starting PBR generation for {iteration_mat.name} (iter {iter_num}, slot {best_slot})")
        
        # 2. Check server mode
        if not runcomfy_deployment.is_server_mode():
            self.report({'ERROR'}, "PBR generation only works in Server mode (GCS)")
            return {'CANCELLED'}
        
        # 3. Extract the iteration texture directly from the material's node tree.
        # This is the single source of truth -- the packed image that was projected.
        # Disk files can be stale across sessions, so we never search disk paths.
        import time
        
        blender_img = None
        for node in iteration_mat.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image:
                blender_img = node.image
                break
        
        if not blender_img:
            self.report({'ERROR'}, f"No image found in {iteration_mat.name} node tree")
            return {'CANCELLED'}
        
        # Save the packed image to a unique temp file for upload
        temp_dir = workspace_setup.get_temp_directory(context)
        timestamp = int(time.time())
        unique_name = f"pbr_input_{iter_num}_{timestamp}.png"
        iteration_image_path = temp_dir / unique_name
        blender_img.save_render(str(iteration_image_path))
        
        print(f"[PBR] Extracted from material node tree: {blender_img.name} -> {unique_name}")
        
        try:
            # 4. Upload texture to ComfyUI
            # File is already uniquely named (timestamped) to prevent ComfyUI cache issues
            server_client = runcomfy_deployment.get_server_client()
            
            print(f"[PBR] Uploading {unique_name} to ComfyUI...")
            upload_response = server_client.upload_image(str(iteration_image_path), overwrite=True)
            uploaded_filename = upload_response.get("name", "")
            
            if not uploaded_filename:
                self.report({'ERROR'}, "Failed to upload texture to server")
                return {'CANCELLED'}
            
            print(f"[PBR] Uploaded: {uploaded_filename}")
            
            # 5. Load and patch workflow
            addon_dir = Path(__file__).parent
            workflow_file = addon_dir / "workflows" / "Object" / "objectPBRproject.json"
            
            if not workflow_file.exists():
                self.report({'ERROR'}, "objectPBRproject.json not found")
                return {'CANCELLED'}
            
            with open(workflow_file, 'r') as f:
                workflow = json.load(f)
            
            print(f"[PBR] Loaded workflow: {workflow_file.name}")
            
            # Patch Node 22 (LoadImage) with uploaded texture
            if "22" not in workflow:
                self.report({'ERROR'}, "Invalid workflow (node 22 missing)")
                return {'CANCELLED'}
            
            workflow["22"]["inputs"]["image"] = uploaded_filename
            print(f"[PBR] Patched node 22 with: {uploaded_filename}")
            
            # 6. Submit to ComfyUI
            print(f"[PBR] Submitting workflow...")
            response = server_client.queue_prompt(workflow)
            prompt_id = response['prompt_id']
            print(f"[PBR] Queued (ID: {prompt_id[:8]}...)")
            
            # 7. Store workflow for progress bar
            progress_bar.set_current_workflow(workflow)
            
            # 8. Capture variables for callback
            obj_name = obj.name
            target_slot = best_slot
            pbr_name = f"pbrmaterial_{iter_num}"
            pbr_dir_name = f"pbr_{iter_num}"
            
            def on_pbr_complete(success, result=None, error=None, workflow_type=None):
                """Callback when PBR generation completes"""
                print(f"[PBR] ============================================")
                print(f"[PBR] PBR GENERATION COMPLETE")
                print(f"[PBR] ============================================")
                
                if not success:
                    print(f"[PBR] Failed: {error}")
                    return
                
                try:
                    from concurrent.futures import ThreadPoolExecutor
                    
                    # Extract output images
                    images = extract_output_images(result)
                    print(f"[PBR] Found {len(images)} output images")
                    
                    if not images:
                        print(f"[PBR] No output images found")
                        return
                    
                    # Create PBR directory
                    pbr_save_dir = None
                    proj_lib = workspace_setup.get_project_library(bpy.context)
                    if proj_lib:
                        pbr_save_dir = proj_lib / "Textures" / pbr_dir_name
                    else:
                        temp = workspace_setup.get_temp_directory(bpy.context)
                        pbr_save_dir = temp / pbr_dir_name
                    
                    pbr_save_dir.mkdir(parents=True, exist_ok=True)
                    print(f"[PBR] Saving PBR maps to: {pbr_save_dir}")
                    
                    # Map prefix to PBR channel
                    pbr_prefixes = {
                        'basecolor': 'basecolor',
                        'normal': 'normal',
                        'roughness': 'roughness',
                        'metalness': 'metalness',
                        'height': 'height',
                    }
                    
                    # Download all maps in parallel
                    download_tasks = []
                    for img_info in images:
                        filename = img_info['filename']
                        subfolder = img_info.get('subfolder', '')
                        
                        # Match filename prefix to PBR channel
                        for prefix, channel in pbr_prefixes.items():
                            if filename.lower().startswith(prefix):
                                save_name = f"pbr_{iter_num}_{channel}.png"
                                save_path = pbr_save_dir / save_name
                                download_tasks.append({
                                    'filename': filename,
                                    'subfolder': subfolder,
                                    'save_path': save_path,
                                    'channel': channel,
                                })
                                break
                    
                    print(f"[PBR] Downloading {len(download_tasks)} PBR maps...")
                    
                    def download_one(task):
                        try:
                            server_client.download_image(
                                task['filename'],
                                str(task['save_path']),
                                subfolder=task['subfolder'],
                            )
                            print(f"[PBR] Downloaded: {task['channel']} -> {task['save_path'].name}")
                            return task
                        except Exception as e:
                            print(f"[PBR] Failed to download {task['channel']}: {e}")
                            return None
                    
                    downloaded = {}
                    with ThreadPoolExecutor(max_workers=4) as executor:
                        results = list(executor.map(download_one, download_tasks))
                    
                    for task in results:
                        if task:
                            downloaded[task['channel']] = task['save_path']
                    
                    print(f"[PBR] Downloaded {len(downloaded)}/{len(download_tasks)} maps")
                    
                    # Check minimum required maps
                    required = ['basecolor', 'normal', 'roughness', 'metalness']
                    missing = [r for r in required if r not in downloaded]
                    if missing:
                        print(f"[PBR] Missing required maps: {missing}")
                        return
                    
                    # ================================================
                    # CREATE PBR MATERIAL
                    # ================================================
                    print(f"[PBR] Creating material: {pbr_name}")
                    
                    mat = bpy.data.materials.new(name=pbr_name)
                    mat.use_nodes = True
                    nodes = mat.node_tree.nodes
                    links = mat.node_tree.links
                    nodes.clear()
                    
                    # -- Texture Coordinate --
                    tex_coord = nodes.new(type='ShaderNodeTexCoord')
                    tex_coord.location = (-900, 0)
                    
                    # -- Mapping --
                    mapping = nodes.new(type='ShaderNodeMapping')
                    mapping.location = (-700, 0)
                    links.new(tex_coord.outputs['UV'], mapping.inputs['Vector'])
                    
                    # -- Base Color --
                    img_basecolor = bpy.data.images.load(str(downloaded['basecolor']))
                    img_basecolor.name = f"pbr_{iter_num}_basecolor"
                    tex_basecolor = nodes.new(type='ShaderNodeTexImage')
                    tex_basecolor.location = (-400, 300)
                    tex_basecolor.image = img_basecolor
                    tex_basecolor.label = "Base Color"
                    links.new(mapping.outputs['Vector'], tex_basecolor.inputs['Vector'])
                    
                    # -- Metalness --
                    img_metalness = bpy.data.images.load(str(downloaded['metalness']))
                    img_metalness.name = f"pbr_{iter_num}_metalness"
                    img_metalness.colorspace_settings.name = 'Non-Color'
                    tex_metalness = nodes.new(type='ShaderNodeTexImage')
                    tex_metalness.location = (-400, 0)
                    tex_metalness.image = img_metalness
                    tex_metalness.label = "Metalness"
                    links.new(mapping.outputs['Vector'], tex_metalness.inputs['Vector'])
                    
                    # -- Roughness --
                    img_roughness = bpy.data.images.load(str(downloaded['roughness']))
                    img_roughness.name = f"pbr_{iter_num}_roughness"
                    img_roughness.colorspace_settings.name = 'Non-Color'
                    tex_roughness = nodes.new(type='ShaderNodeTexImage')
                    tex_roughness.location = (-400, -300)
                    tex_roughness.image = img_roughness
                    tex_roughness.label = "Roughness"
                    links.new(mapping.outputs['Vector'], tex_roughness.inputs['Vector'])
                    
                    # -- Normal --
                    img_normal = bpy.data.images.load(str(downloaded['normal']))
                    img_normal.name = f"pbr_{iter_num}_normal"
                    img_normal.colorspace_settings.name = 'Non-Color'
                    tex_normal = nodes.new(type='ShaderNodeTexImage')
                    tex_normal.location = (-400, -600)
                    tex_normal.image = img_normal
                    tex_normal.label = "Normal"
                    links.new(mapping.outputs['Vector'], tex_normal.inputs['Vector'])
                    
                    # -- Normal Map node --
                    normal_map = nodes.new(type='ShaderNodeNormalMap')
                    normal_map.location = (-100, -600)
                    normal_map.space = 'TANGENT'
                    normal_map.inputs['Strength'].default_value = 1.0
                    links.new(tex_normal.outputs['Color'], normal_map.inputs['Color'])
                    
                    # -- Principled BSDF --
                    bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
                    bsdf.location = (200, 0)
                    
                    links.new(tex_basecolor.outputs['Color'], bsdf.inputs['Base Color'])
                    links.new(tex_metalness.outputs['Color'], bsdf.inputs['Metallic'])
                    links.new(tex_roughness.outputs['Color'], bsdf.inputs['Roughness'])
                    links.new(normal_map.outputs['Normal'], bsdf.inputs['Normal'])
                    
                    # -- Material Output --
                    output = nodes.new(type='ShaderNodeOutputMaterial')
                    output.location = (500, 0)
                    links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
                    
                    # ================================================
                    # ASSIGN MATERIAL TO OBJECT (replace same slot)
                    # ================================================
                    target_obj = bpy.data.objects.get(obj_name)
                    if target_obj and target_obj.type == 'MESH':
                        # Replace the exact slot where iteration_XXX was
                        if target_obj.data.materials and target_slot < len(target_obj.data.materials):
                            target_obj.data.materials[target_slot] = mat
                            print(f"[PBR] Replaced slot {target_slot} on {target_obj.name} with {pbr_name}")
                        else:
                            target_obj.data.materials.append(mat)
                            print(f"[PBR] Appended {pbr_name} to {target_obj.name}")
                    else:
                        print(f"[PBR] Object '{obj_name}' not found, material created but not assigned")
                    
                    print(f"[PBR] ============================================")
                    print(f"[PBR] PBR MATERIAL CREATED: {pbr_name}")
                    print(f"[PBR]   Base Color: {downloaded['basecolor'].name}")
                    print(f"[PBR]   Metalness:  {downloaded['metalness'].name}")
                    print(f"[PBR]   Roughness:  {downloaded['roughness'].name}")
                    print(f"[PBR]   Normal:     {downloaded['normal'].name}")
                    if 'height' in downloaded:
                        print(f"[PBR]   Height:     {downloaded['height'].name} (saved, not used in shader)")
                    print(f"[PBR] ============================================")
                    
                except Exception as e:
                    print(f"[PBR] Error in callback: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Register for non-blocking polling
            runcomfy_polling.RunComfyPoller.start_polling(
                deployment_id='server',
                request_id=prompt_id,
                callback=on_pbr_complete,
                workflow_type='pbr'
            )
            
            self.report({'INFO'}, f"Generating PBR maps for iteration_{iter_num}... (watch progress bar)")
            print(f"[PBR] Processing in background...")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"PBR generation failed: {str(e)}")
            print(f"[PBR] Error: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}


# ================================================================
# PBR FROM TEXT PROMPT OPERATOR
# ================================================================

class WM_OT_PBRFromText(bpy.types.Operator):
    """Generate a PBR material from a text prompt using chord_v1"""
    bl_idname = "style_engine.pbr_from_text"
    bl_label = "Generate PBR Material"
    bl_description = "Generate PBR maps (basecolor, normal, roughness, metalness) from a text description"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        import json
        from pathlib import Path
        from . import runcomfy_deployment
        from . import workspace_setup
        from . import progress_bar
        from . import runcomfy_polling
        from . import utils
        from .runcomfy_server_client import extract_output_images
        
        # 1. Check server mode
        if not runcomfy_deployment.is_server_mode():
            self.report({'ERROR'}, "PBR generation only works in Server mode (GCS)")
            return {'CANCELLED'}
        
        # 2. Parse prompts from text editor
        prompt_from_editor = utils.get_prompt_from_text_editor()
        if not prompt_from_editor:
            self.report({'ERROR'}, "No prompt found in STYLEENGINE_Prompt text block")
            return {'CANCELLED'}
        
        positive_prompt, negative_prompt = utils.process_prompt_builder(prompt_from_editor)
        
        if not positive_prompt:
            self.report({'ERROR'}, "No positive prompt found. Write a texture description in the <p> tag.")
            return {'CANCELLED'}
        
        print(f"[PBR Text] Positive: {positive_prompt[:80]}...")
        print(f"[PBR Text] Negative: {negative_prompt[:80]}..." if negative_prompt else "[PBR Text] Negative: (none)")
        
        try:
            server_client = runcomfy_deployment.get_server_client()
            
            # 3. Load and patch workflow
            addon_dir = Path(__file__).parent
            workflow_file = addon_dir / "workflows" / "Object" / "objectPBRtext.json"
            
            if not workflow_file.exists():
                self.report({'ERROR'}, "objectPBRtext.json not found")
                return {'CANCELLED'}
            
            with open(workflow_file, 'r') as f:
                workflow = json.load(f)
            
            print(f"[PBR Text] Loaded workflow: {workflow_file.name}")
            
            # Patch Node 38 (Text Multiline) with positive prompt
            if "38" in workflow:
                workflow["38"]["inputs"]["text"] = positive_prompt
                print(f"[PBR Text] Patched node 38 (prompt): {positive_prompt[:60]}...")
            
            # Patch Node 25 (CLIPTextEncode) with negative prompt
            if "25" in workflow:
                workflow["25"]["inputs"]["text"] = negative_prompt or ""
                print(f"[PBR Text] Patched node 25 (negative): {negative_prompt[:60]}..." if negative_prompt else "[PBR Text] Patched node 25 (negative): empty")
            
            # 4. Submit to ComfyUI
            print(f"[PBR Text] Submitting workflow...")
            response = server_client.queue_prompt(workflow)
            prompt_id = response['prompt_id']
            print(f"[PBR Text] Queued (ID: {prompt_id[:8]}...)")
            
            # 5. Store workflow for progress bar
            progress_bar.set_current_workflow(workflow)
            
            # 6. Capture variables for callback
            obj_name = None
            obj = context.active_object
            if obj and obj.type == 'MESH':
                obj_name = obj.name
            
            def on_pbr_text_complete(success, result=None, error=None, workflow_type=None):
                """Callback when text-to-PBR generation completes"""
                print(f"[PBR Text] ============================================")
                print(f"[PBR Text] TEXT-TO-PBR GENERATION COMPLETE")
                print(f"[PBR Text] ============================================")
                
                if not success:
                    print(f"[PBR Text] Failed: {error}")
                    return
                
                try:
                    from concurrent.futures import ThreadPoolExecutor
                    
                    # Extract output images
                    images = extract_output_images(result)
                    print(f"[PBR Text] Found {len(images)} output images")
                    
                    if not images:
                        print(f"[PBR Text] No output images found")
                        return
                    
                    # Auto-increment naming: find next available pbr_text_XXX
                    pbr_num = 0
                    while f"pbrmaterial_text_{pbr_num:03d}" in bpy.data.materials:
                        pbr_num += 1
                    
                    iter_num = f"{pbr_num:03d}"
                    pbr_name = f"pbrmaterial_text_{iter_num}"
                    pbr_dir_name = f"pbr_text_{iter_num}"
                    
                    print(f"[PBR Text] Using name: {pbr_name}")
                    
                    # Create PBR directory
                    pbr_save_dir = None
                    proj_lib = workspace_setup.get_project_library(bpy.context)
                    if proj_lib:
                        pbr_save_dir = proj_lib / "Textures" / pbr_dir_name
                    else:
                        temp = workspace_setup.get_temp_directory(bpy.context)
                        pbr_save_dir = temp / pbr_dir_name
                    
                    pbr_save_dir.mkdir(parents=True, exist_ok=True)
                    print(f"[PBR Text] Saving PBR maps to: {pbr_save_dir}")
                    
                    # Map prefix to PBR channel
                    pbr_prefixes = {
                        'texture_image': 'texture_image',
                        'basecolor': 'basecolor',
                        'normal': 'normal',
                        'roughness': 'roughness',
                        'metalness': 'metalness',
                        'height': 'height',
                    }
                    
                    # Download all maps in parallel
                    download_tasks = []
                    for img_info in images:
                        filename = img_info['filename']
                        subfolder = img_info.get('subfolder', '')
                        
                        for prefix, channel in pbr_prefixes.items():
                            if filename.lower().startswith(prefix):
                                save_name = f"pbr_text_{iter_num}_{channel}.png"
                                save_path = pbr_save_dir / save_name
                                download_tasks.append({
                                    'filename': filename,
                                    'subfolder': subfolder,
                                    'save_path': save_path,
                                    'channel': channel,
                                })
                                break
                    
                    print(f"[PBR Text] Downloading {len(download_tasks)} maps...")
                    
                    def download_one(task):
                        try:
                            server_client.download_image(
                                task['filename'],
                                str(task['save_path']),
                                subfolder=task['subfolder'],
                            )
                            print(f"[PBR Text] Downloaded: {task['channel']} -> {task['save_path'].name}")
                            return task
                        except Exception as e:
                            print(f"[PBR Text] Failed to download {task['channel']}: {e}")
                            return None
                    
                    downloaded = {}
                    with ThreadPoolExecutor(max_workers=4) as executor:
                        results = list(executor.map(download_one, download_tasks))
                    
                    for task in results:
                        if task:
                            downloaded[task['channel']] = task['save_path']
                    
                    print(f"[PBR Text] Downloaded {len(downloaded)}/{len(download_tasks)} maps")
                    
                    # Check minimum required maps
                    required = ['basecolor', 'normal', 'roughness', 'metalness']
                    missing = [r for r in required if r not in downloaded]
                    if missing:
                        print(f"[PBR Text] Missing required maps: {missing}")
                        return
                    
                    # ================================================
                    # CREATE PBR MATERIAL
                    # ================================================
                    print(f"[PBR Text] Creating material: {pbr_name}")
                    
                    mat = bpy.data.materials.new(name=pbr_name)
                    mat.use_nodes = True
                    nodes = mat.node_tree.nodes
                    links = mat.node_tree.links
                    nodes.clear()
                    
                    # -- Texture Coordinate --
                    tex_coord = nodes.new(type='ShaderNodeTexCoord')
                    tex_coord.location = (-900, 0)
                    
                    # -- Mapping --
                    mapping = nodes.new(type='ShaderNodeMapping')
                    mapping.location = (-700, 0)
                    links.new(tex_coord.outputs['UV'], mapping.inputs['Vector'])
                    
                    # -- Base Color --
                    img_basecolor = bpy.data.images.load(str(downloaded['basecolor']))
                    img_basecolor.name = f"pbr_text_{iter_num}_basecolor"
                    tex_basecolor = nodes.new(type='ShaderNodeTexImage')
                    tex_basecolor.location = (-400, 300)
                    tex_basecolor.image = img_basecolor
                    tex_basecolor.label = "Base Color"
                    links.new(mapping.outputs['Vector'], tex_basecolor.inputs['Vector'])
                    
                    # -- Metalness --
                    img_metalness = bpy.data.images.load(str(downloaded['metalness']))
                    img_metalness.name = f"pbr_text_{iter_num}_metalness"
                    img_metalness.colorspace_settings.name = 'Non-Color'
                    tex_metalness = nodes.new(type='ShaderNodeTexImage')
                    tex_metalness.location = (-400, 0)
                    tex_metalness.image = img_metalness
                    tex_metalness.label = "Metalness"
                    links.new(mapping.outputs['Vector'], tex_metalness.inputs['Vector'])
                    
                    # -- Roughness --
                    img_roughness = bpy.data.images.load(str(downloaded['roughness']))
                    img_roughness.name = f"pbr_text_{iter_num}_roughness"
                    img_roughness.colorspace_settings.name = 'Non-Color'
                    tex_roughness = nodes.new(type='ShaderNodeTexImage')
                    tex_roughness.location = (-400, -300)
                    tex_roughness.image = img_roughness
                    tex_roughness.label = "Roughness"
                    links.new(mapping.outputs['Vector'], tex_roughness.inputs['Vector'])
                    
                    # -- Normal --
                    img_normal = bpy.data.images.load(str(downloaded['normal']))
                    img_normal.name = f"pbr_text_{iter_num}_normal"
                    img_normal.colorspace_settings.name = 'Non-Color'
                    tex_normal = nodes.new(type='ShaderNodeTexImage')
                    tex_normal.location = (-400, -600)
                    tex_normal.image = img_normal
                    tex_normal.label = "Normal"
                    links.new(mapping.outputs['Vector'], tex_normal.inputs['Vector'])
                    
                    # -- Normal Map node --
                    normal_map = nodes.new(type='ShaderNodeNormalMap')
                    normal_map.location = (-100, -600)
                    normal_map.space = 'TANGENT'
                    normal_map.inputs['Strength'].default_value = 1.0
                    links.new(tex_normal.outputs['Color'], normal_map.inputs['Color'])
                    
                    # -- Principled BSDF --
                    bsdf = nodes.new(type='ShaderNodeBsdfPrincipled')
                    bsdf.location = (200, 0)
                    
                    links.new(tex_basecolor.outputs['Color'], bsdf.inputs['Base Color'])
                    links.new(tex_metalness.outputs['Color'], bsdf.inputs['Metallic'])
                    links.new(tex_roughness.outputs['Color'], bsdf.inputs['Roughness'])
                    links.new(normal_map.outputs['Normal'], bsdf.inputs['Normal'])
                    
                    # -- Material Output --
                    output = nodes.new(type='ShaderNodeOutputMaterial')
                    output.location = (500, 0)
                    links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
                    
                    # ================================================
                    # ASSIGN MATERIAL TO ACTIVE MESH (if any)
                    # ================================================
                    if obj_name:
                        target_obj = bpy.data.objects.get(obj_name)
                        if target_obj and target_obj.type == 'MESH':
                            if target_obj.data.materials:
                                target_obj.data.materials[0] = mat
                            else:
                                target_obj.data.materials.append(mat)
                            print(f"[PBR Text] Assigned {pbr_name} to {target_obj.name}")
                        else:
                            print(f"[PBR Text] Object '{obj_name}' not found, material created but not assigned")
                    else:
                        print(f"[PBR Text] No active mesh, material '{pbr_name}' created (assign manually)")
                    
                    print(f"[PBR Text] ============================================")
                    print(f"[PBR Text] PBR MATERIAL CREATED: {pbr_name}")
                    print(f"[PBR Text]   Base Color: {downloaded['basecolor'].name}")
                    print(f"[PBR Text]   Metalness:  {downloaded['metalness'].name}")
                    print(f"[PBR Text]   Roughness:  {downloaded['roughness'].name}")
                    print(f"[PBR Text]   Normal:     {downloaded['normal'].name}")
                    if 'height' in downloaded:
                        print(f"[PBR Text]   Height:     {downloaded['height'].name} (saved, not used in shader)")
                    if 'texture_image' in downloaded:
                        print(f"[PBR Text]   Texture:    {downloaded['texture_image'].name} (raw generated, saved)")
                    print(f"[PBR Text] ============================================")
                    
                except Exception as e:
                    print(f"[PBR Text] Error in callback: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Register for non-blocking polling
            runcomfy_polling.RunComfyPoller.start_polling(
                deployment_id='server',
                request_id=prompt_id,
                callback=on_pbr_text_complete,
                workflow_type='pbr'
            )
            
            self.report({'INFO'}, f"Generating PBR material from text... (watch progress bar)")
            print(f"[PBR Text] Processing in background...")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"PBR text generation failed: {str(e)}")
            print(f"[PBR Text] Error: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}


# ================================================================
# REFERENCE IMAGE OPERATORS
# ================================================================

class WM_OT_LoadReferenceImage(bpy.types.Operator):
    """Load a reference image into a slot"""
    bl_idname = "style_engine.load_reference"
    bl_label = "Load Reference Image"
    bl_options = {'REGISTER', 'UNDO'}
    
    filepath: bpy.props.StringProperty(
        subtype='FILE_PATH',
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    
    filter_image: bpy.props.BoolProperty(
        default=True,
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    
    filter_folder: bpy.props.BoolProperty(
        default=True,
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    
    slot: bpy.props.StringProperty(
        name="Slot",
        description="Which slot to load the image into (st1, comp2, sst3, etc.)",
        default=""
    )
    
    def execute(self, context):
        if not self.filepath:
            self.report({'ERROR'}, "No file selected")
            return {'CANCELLED'}
        
        if not self.slot:
            self.report({'ERROR'}, "No slot specified")
            return {'CANCELLED'}
        
        try:
            print(f"\n{'='*60}")
            print(f"[Reference Image Load] Starting load for slot: {self.slot}")
            print(f"[Reference Image Load] File path: {self.filepath}")
            
            # Load image into Blender's image library
            img = bpy.data.images.load(self.filepath, check_existing=True)
            print(f"[Reference Image Load] Image loaded: {img.name}")
            print(f"[Reference Image Load]   Size: {img.size[0]}x{img.size[1]}")
            print(f"[Reference Image Load]   Type: {img.type}")
            print(f"[Reference Image Load]   Source: {img.source}")
            print(f"[Reference Image Load]   Has data: {img.has_data}")
            print(f"[Reference Image Load]   Is dirty: {img.is_dirty}")
            
            # Pack the image to force Blender to load it and generate preview
            # This is needed for template_ID_preview() to show thumbnails
            if not img.packed_file:
                print(f"[Reference Image Load] Packing image...")
                img.pack()
                print(f"[Reference Image Load]   Packed file size: {img.packed_file.size if img.packed_file else 'None'}")
            else:
                print(f"[Reference Image Load] Image already packed")
            
            # Force pixels to load FIRST (needed before GL load)
            print(f"[Reference Image Load] Loading pixel data...")
            img.reload()
            pixels_len = len(img.pixels)
            print(f"[Reference Image Load]   Pixels loaded: {pixels_len} values")
            
            # Force GL texture load (requires pixels to be loaded)
            print(f"[Reference Image Load] Forcing GL texture load...")
            img.gl_load()
            print(f"[Reference Image Load]   GL loaded: {img.bindcode}")
            
            # CRITICAL: Generate preview icon for UI display
            print(f"[Reference Image Load] Generating preview icon...")
            img.preview_ensure()
            if img.preview:
                print(f"[Reference Image Load]   Preview icon ID: {img.preview.icon_id}")
                print(f"[Reference Image Load]   Preview size: {img.preview.image_size}")
            else:
                print(f"[Reference Image Load]   ⚠️ Preview is None!")
            
            # Force update
            img.update()
            print(f"[Reference Image Load] Image updated")
            
            # Assign to the specified slot
            props = context.scene.style_engine_props
            img_prop = f"{self.slot}_image"
            weight_prop = f"{self.slot}_weight"
            
            print(f"[Reference Image Load] Assigning to property: {img_prop}")
            setattr(props, img_prop, img)
            
            # Auto-enable by setting weight to 1.0 (user can adjust)
            current_weight = getattr(props, weight_prop)
            if current_weight == 0.0:
                setattr(props, weight_prop, 1.0)
                print(f"[Reference Image Load] Weight set to 1.0")
            else:
                print(f"[Reference Image Load] Weight already at {current_weight}")
            
            # Force UI redraw for thumbnail to appear
            print(f"[Reference Image Load] Forcing UI redraw...")
            for area in context.screen.areas:
                area.tag_redraw()
            
            print(f"[Reference Image Load] ✅ Complete!")
            print(f"{'='*60}\n")
            
            self.report({'INFO'}, f"Loaded {img.name} into {self.slot.upper()}")
            print(f"[Style Engine] ✓ Loaded reference image: {img.name} → {self.slot.upper()} (packed)")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load image: {e}")
            print(f"[Style Engine] ❌ Error loading reference image: {e}")
            return {'CANCELLED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class WM_OT_ClearReferenceImage(bpy.types.Operator):
    """Clear a reference image slot"""
    bl_idname = "style_engine.clear_reference"
    bl_label = "Clear Reference Image"
    bl_options = {'REGISTER', 'UNDO'}
    
    slot: bpy.props.StringProperty(
        name="Slot",
        description="Which slot to clear (st1, comp2, sst3, etc.)",
        default=""
    )
    
    def execute(self, context):
        if not self.slot:
            self.report({'ERROR'}, "No slot specified")
            return {'CANCELLED'}
        
        try:
            props = context.scene.style_engine_props
            img_prop = f"{self.slot}_image"
            weight_prop = f"{self.slot}_weight"
            
            # Clear the image
            setattr(props, img_prop, None)
            
            # Reset weight to 0
            setattr(props, weight_prop, 0.0)
            
            self.report({'INFO'}, f"Cleared {self.slot.upper()}")
            print(f"[Style Engine] ✓ Cleared reference image: {self.slot.upper()}")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to clear slot: {e}")
            print(f"[Style Engine] ❌ Error clearing reference slot: {e}")
            return {'CANCELLED'}


class WM_OT_ReloadReferenceImage(bpy.types.Operator):
    """Reload a reference image from disk"""
    bl_idname = "style_engine.reload_reference"
    bl_label = "Reload Reference Image"
    bl_options = {'REGISTER', 'UNDO'}
    
    slot: bpy.props.StringProperty(
        name="Slot",
        description="Which slot to reload (st1, comp2, sst3, etc.)",
        default=""
    )
    
    def execute(self, context):
        if not self.slot:
            self.report({'ERROR'}, "No slot specified")
            return {'CANCELLED'}
        
        try:
            props = context.scene.style_engine_props
            img_prop = f"{self.slot}_image"
            img = getattr(props, img_prop)
            
            if not img:
                self.report({'WARNING'}, f"No image in {self.slot.upper()}")
                return {'CANCELLED'}
            
            # Reload the image from disk
            img.reload()
            
            # Pack if not already packed (for preview generation)
            if not img.packed_file:
                img.pack()
            
            # Force GL load
            img.gl_load()
            
            # CRITICAL: Regenerate preview icon
            img.preview_ensure()
            
            # Force update
            img.update()
            
            # Force UI redraw for thumbnail to update
            for area in context.screen.areas:
                area.tag_redraw()
            
            self.report({'INFO'}, f"Reloaded {img.name}")
            print(f"[Style Engine] ✓ Reloaded reference image: {img.name}")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to reload image: {e}")
            print(f"[Style Engine] ❌ Error reloading reference image: {e}")
            return {'CANCELLED'}


class WM_OT_CancelGeneration(bpy.types.Operator):
    """Cancel active RunComfy generation"""
    bl_idname = "style_engine.cancel_generation"
    bl_label = "Cancel Generation"
    bl_description = "Cancel the active cloud generation request"
    
    request_id: bpy.props.StringProperty()
    
    def execute(self, context):
        from . import runcomfy_polling
        
        if runcomfy_polling.RunComfyPoller.cancel_request(self.request_id):
            self.report({'INFO'}, f"Cancelled request {self.request_id[:8]}")
            print(f"[Style Engine] Cancelled request {self.request_id[:8]}")
        else:
            self.report({'WARNING'}, "Request not found or already completed")
        
        return {'FINISHED'}


class WM_OT_RefreshLoraList(bpy.types.Operator):
    """Refresh LoRa list from ComfyUI server"""
    bl_idname = "style_engine.refresh_lora_list"
    bl_label = "Refresh LoRa List"
    bl_description = "Fetch latest LoRa models from ComfyUI server (clears 5-min cache)"
    
    def execute(self, context):
        # Clear cache
        global _lora_cache
        _lora_cache['items'] = []
        _lora_cache['timestamp'] = 0
        
        # Trigger refresh by accessing the property
        props = context.scene.style_engine_props
        current = props.lora_name
        
        # Force UI update
        for area in context.screen.areas:
            area.tag_redraw()
        
        self.report({'INFO'}, "LoRa list refreshed from server")
        print("[Style Engine] LoRa cache cleared - will refresh on next dropdown open")
        
        return {'FINISHED'}


class WM_OT_LoadLoraKeywords(bpy.types.Operator):
    """Load trigger keywords for the selected LoRa into the <k> tag"""
    bl_idname = "style_engine.load_lora_keywords"
    bl_label = "Load Keywords"
    bl_description = "Load trigger keywords for the selected LoRa(s) into the <k> tag in the prompt editor"
    
    def execute(self, context):
        import re
        from pathlib import Path
        from . import workspace_setup
        
        props = context.scene.style_engine_props
        
        # 1. Load keywords.txt
        addon_dir = Path(__file__).parent
        keywords_file = addon_dir / "loras" / "keywords.txt"
        
        if not keywords_file.exists():
            self.report({'ERROR'}, "keywords.txt not found")
            print(f"[Load Keywords] ❌ File not found: {keywords_file}")
            return {'CANCELLED'}
        
        # Parse keywords.txt (format: "filename.safetensors: "keywords here"")
        keyword_map = {}
        with open(keywords_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                # Split on first colon
                if ':' in line:
                    parts = line.split(':', 1)
                    lora_name = parts[0].strip()
                    keywords_raw = parts[1].strip().strip('"').strip()
                    if lora_name and keywords_raw:
                        keyword_map[lora_name] = keywords_raw
        
        if not keyword_map:
            self.report({'ERROR'}, "keywords.txt is empty or has no valid entries")
            return {'CANCELLED'}
        
        print(f"[Load Keywords] Loaded {len(keyword_map)} keyword entries")
        
        # 2. Collect keywords from active LoRAs
        collected_keywords = []
        
        if props.lora_enabled and props.lora_name != 'NONE':
            if props.lora_name in keyword_map:
                collected_keywords.append(keyword_map[props.lora_name])
                print(f"[Load Keywords] LoRa 1 ({props.lora_name}): {keyword_map[props.lora_name]}")
            else:
                print(f"[Load Keywords] LoRa 1 ({props.lora_name}): No keywords found")
        
        if props.lora2_enabled and props.lora2_name != 'NONE':
            if props.lora2_name in keyword_map:
                collected_keywords.append(keyword_map[props.lora2_name])
                print(f"[Load Keywords] LoRa 2 ({props.lora2_name}): {keyword_map[props.lora2_name]}")
            else:
                print(f"[Load Keywords] LoRa 2 ({props.lora2_name}): No keywords found")
        
        if not collected_keywords:
            self.report({'WARNING'}, "No keywords found for selected LoRa(s)")
            return {'CANCELLED'}
        
        # 3. Get text editor
        text_block = bpy.data.texts.get("STYLEENGINE_Prompt")
        if not text_block:
            self.report({'ERROR'}, "STYLEENGINE_Prompt text block not found")
            return {'CANCELLED'}
        
        # Save before snapshot
        workspace_setup.save_prompt_snapshot(context, prefix="before_keywords")
        
        # 4. Insert into <k> tag
        current_content = text_block.as_string()
        new_keywords = ', '.join(collected_keywords)
        
        k_match = re.search(r'<k>(.*?)</k>', current_content, re.DOTALL | re.IGNORECASE)
        if k_match:
            existing_k = k_match.group(1).strip()
            if existing_k:
                # Append to existing keywords
                final_keywords = existing_k + ', ' + new_keywords
            else:
                final_keywords = new_keywords
            new_content = re.sub(
                r'(<k>)(.*?)(</k>)',
                r'\1' + final_keywords + r'\3',
                current_content,
                flags=re.DOTALL | re.IGNORECASE
            )
        else:
            # No <k> tag, add one at the top
            new_content = f"<k>{new_keywords}</k>\n" + current_content
        
        text_block.clear()
        text_block.write(new_content)
        
        # Save after snapshot
        workspace_setup.save_prompt_snapshot(context, prefix="after_keywords")
        
        self.report({'INFO'}, f"Keywords loaded: {new_keywords[:60]}...")
        print(f"[Load Keywords] ✓ Inserted into <k> tag: {new_keywords}")
        return {'FINISHED'}


class WM_OT_TestCloudGeneration(bpy.types.Operator):
    """Test workflow with current settings (dev tool)"""
    bl_idname = "style_engine.test_cloud_generation"
    bl_label = "Test Workflow"
    bl_description = "Test the workflow JSON with current settings (development/debugging)"
    
    def execute(self, context):
        from . import workspace_setup
        
        try:
            workspace_setup.generate_ai_image_cloud(context)
            self.report({'INFO'}, "Test workflow started")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to start test: {e}")
            print(f"[Style Engine] Error: {e}")
        
        return {'FINISHED'}


# ----------------------------------------------------------------
# 3. UI PANEL
# ----------------------------------------------------------------
class VIEW3D_PT_StyleEngine(bpy.types.Panel):
    """The main UI panel for the Style Engine."""
    bl_label = "Style Engine"
    bl_idname = "VIEW3D_PT_style_engine"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Style Engine'

    def draw(self, context):
        layout = self.layout
        style_props = context.scene.style_engine_props

        # ================================================================
        # SERVER STATUS (Always visible, non-collapsible)
        # ================================================================
        from . import progress_bar
        
        status_box = layout.box()
        
        # Row 1: Connection status with colored indicators
        # Green = idle/ready, Yellow = processing, Red = offline
        row = status_box.row(align=True)
        connection = progress_bar.get_connection_status()
        progress = progress_bar.get_display_progress()
        display_status = progress_bar.get_display_status()
        progress_pct = int(progress * 100)
        
        if connection != "connected":
            # RED: Offline/Disconnected
            row.label(text="", icon='KEYTYPE_EXTREME_VEC')
            row.label(text="Server: Offline")
        elif display_status == "ready" and (progress == 0 or progress >= 1.0):
            # GREEN: Online and Idle (explicitly ready, or finished at 100%)
            row.label(text="", icon='KEYTYPE_JITTER_VEC')
            row.label(text="Server: Ready")
        elif display_status in ("processing", "finishing") or (0 < progress < 1.0):
            # YELLOW: Actively processing (status says so, or progress is between 0-100%)
            row.label(text="", icon='KEYTYPE_KEYFRAME_VEC')
            row.label(text="Server: Working...")
        else:
            # GREEN: Default to ready for any other case
            row.label(text="", icon='KEYTYPE_JITTER_VEC')
            row.label(text="Server: Ready")
        
        # Row 2: Progress bar using Unicode block characters (pure display, no property)
        row = status_box.row(align=True)
        bar_length = 15  # Reduced from 20 to fit panel width
        filled = int(bar_length * progress)
        empty = bar_length - filled
        bar_text = "▓" * filled + "░" * empty
        row.label(text=f"{bar_text} {progress_pct}%")
        
        # Row 3: Current node/status (only when processing)
        node_name = progress_bar.get_display_node()
        if node_name and node_name != "Idle" and progress > 0:
            row = status_box.row(align=True)
            row.scale_y = 0.8
            row.label(text=f"  {node_name}", icon='NODE')
        
        # Row 4: Queue (only show if > 0)
        last_status = progress_bar.get_last_status()
        queue = last_status.get('queue_remaining', 0) if last_status else 0
        if queue > 0:
            row = status_box.row(align=True)
            row.scale_y = 0.8
            row.label(text=f"Queue: {queue}", icon='LINENUMBERS_ON')

        # ================================================================
        # FILE CATEGORY (Collapsible)
        # ================================================================
        file_box = layout.box()
        file_header = file_box.row(align=True)
        icon = 'TRIA_DOWN' if style_props.show_file_settings else 'TRIA_RIGHT'
        file_header.prop(style_props, "show_file_settings", text="File", icon=icon, emboss=False, toggle=True)
        file_header.label(text="", icon='FILE_FOLDER')
        
        if style_props.show_file_settings:
            # Output Path
            col = file_box.column(align=True)
            col.label(text="Output Path:")
            col.prop(style_props, "output_path", text="")
            
            # Resolution
            file_box.separator()
            col = file_box.column(align=True)
            col.label(text="Resolution:")
            col.prop(style_props, "ai_resolution", text="")
            
            # Render Quality
            file_box.separator()
            col = file_box.column(align=True)
            col.label(text="Render Quality:")
            col.prop(style_props, "render_quality", text="")
            
            # ────────────────────────────────────────────────────────────
            # VIEW SUB-CATEGORY (Collapsible)
            # ────────────────────────────────────────────────────────────
            file_box.separator()
            view_box = file_box.box()
            view_header = view_box.row(align=True)
            view_icon = 'TRIA_DOWN' if style_props.show_view_settings else 'TRIA_RIGHT'
            view_header.prop(style_props, "show_view_settings", text="View", icon=view_icon, emboss=False, toggle=True)
            view_header.label(text="", icon='VIEW_CAMERA')
            
            if style_props.show_view_settings:
                # Visualization Type Buttons
                col = view_box.column(align=True)
                col.label(text="Visualization:")
                row = col.row(align=True)
                row.scale_y = 1.3
                
                # Combined button
                op = row.operator("style_engine.set_visualization", 
                                 text="Combined", 
                                 icon='IMAGE_DATA',
                                 depress=(style_props.visualization_type == 'COMBINED'))
                op.viz_type = 'COMBINED'
                
                # Silhouette button
                op = row.operator("style_engine.set_visualization", 
                                 text="Silhouette", 
                                 icon='MESH_PLANE',
                                 depress=(style_props.visualization_type == 'CANNY'))
                op.viz_type = 'CANNY'
                
                # Depth button
                op = row.operator("style_engine.set_visualization", 
                                 text="Depth", 
                                 icon='EMPTY_SINGLE_ARROW',
                                 depress=(style_props.visualization_type == 'DEPTH'))
                op.viz_type = 'DEPTH'
                
                # Background Opacity
                view_box.separator()
                col = view_box.column(align=True)
                col.label(text="Background Opacity:")
                col.prop(style_props, "background_opacity", text="", slider=True)
                
                # Generation Browser
                view_box.separator()
                col = view_box.column(align=True)
                col.label(text="Generation Browser:")
                
                # Get generation info
                from . import workspace_setup
                generations = workspace_setup.get_generation_list(context)
                
                if generations:
                    # Navigation buttons
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    
                    # Check if at boundaries
                    at_oldest = (style_props.current_generation_index == 0)
                    at_latest = (style_props.current_generation_index == -1)
                    
                    # Previous button (go to older)
                    prev_row = row.row(align=True)
                    prev_row.enabled = not at_oldest
                    prev_row.operator("style_engine.prev_generation", text="", icon='TRIA_LEFT')
                    
                    # Current generation indicator
                    if at_latest:
                        current_text = f"Latest ({len(generations)})"
                    else:
                        current_text = f"{style_props.current_generation_index + 1}/{len(generations)}"
                    
                    row.label(text=current_text)
                    
                    # Next button (go to newer)
                    next_row = row.row(align=True)
                    next_row.enabled = not at_latest
                    next_row.operator("style_engine.next_generation", text="", icon='TRIA_RIGHT')
                else:
                    col.label(text="No generations yet", icon='INFO')

        # ================================================================
        # VISUALIZATION CATEGORY (Collapsible)
        # ================================================================
        layout.separator()
        vis_box = layout.box()
        vis_header = vis_box.row(align=True)
        vis_icon = 'TRIA_DOWN' if style_props.show_visualization else 'TRIA_RIGHT'
        vis_header.prop(style_props, "show_visualization", text="Visualization", icon=vis_icon, emboss=False, toggle=True)
        vis_header.label(text="", icon='VIEW_CAMERA')
        
        if style_props.show_visualization:
            # Check if preview images are enabled
            prefs = context.preferences.addons.get('styleengine')
            show_viz_controls = (prefs and 
                                prefs.preferences.api_backend == 'GCS' and 
                                prefs.preferences.gcs_download_preview_images)
            
            if show_viz_controls:
                # Visualization type buttons
                col = vis_box.column(align=True)
                col.label(text="Display Mode:")
                row = col.row(align=True)
                row.scale_y = 1.3
                
                # Combined button
                op = row.operator("style_engine.set_visualization", 
                                 text="Combined", 
                                 icon='IMAGE_DATA',
                                 depress=(style_props.visualization_type == 'COMBINED'))
                op.viz_type = 'COMBINED'
                
                # Silhouette button
                op = row.operator("style_engine.set_visualization", 
                                 text="Silhouette", 
                                 icon='MESH_PLANE',
                                 depress=(style_props.visualization_type == 'CANNY'))
                op.viz_type = 'CANNY'
                
                # Depth button
                op = row.operator("style_engine.set_visualization", 
                                 text="Depth", 
                                 icon='EMPTY_SINGLE_ARROW',
                                 depress=(style_props.visualization_type == 'DEPTH'))
                op.viz_type = 'DEPTH'
                
                # Current visualization
                vis_box.separator()
                col = vis_box.column(align=True)
                col.label(text=f"Current: {style_props.visualization_type.title()}", icon='INFO')
                
                # Background opacity
                vis_box.separator()
                col = vis_box.column(align=True)
                col.label(text="Background Opacity")
                col.prop(style_props, "background_opacity", text="", slider=True)
                
                # Generation Browser
                vis_box.separator()
                col = vis_box.column(align=True)
                col.label(text="Generation Browser", icon='RENDERLAYERS')
                
                # Get generation info
                from . import workspace_setup
                generations = workspace_setup.get_generation_list(context)
                
                if generations:
                    # Navigation buttons
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    
                    # Check current position
                    current_gen = getattr(context.scene, 'styleengine_current_generation', len(generations) - 1)
                    at_oldest = current_gen <= 0
                    at_latest = current_gen >= len(generations) - 1
                    
                    # Prev button
                    prev_row = row.row(align=True)
                    prev_row.enabled = not at_oldest
                    prev_row.operator("style_engine.prev_generation", text="", icon='TRIA_LEFT')
                    
                    # Current position label
                    row.label(text=f"{current_gen + 1} / {len(generations)}")
                    
                    # Next button
                    next_row = row.row(align=True)
                    next_row.enabled = not at_latest
                    next_row.operator("style_engine.next_generation", text="", icon='TRIA_RIGHT')
                else:
                    col.label(text="No generations yet", icon='INFO')
            else:
                # Show info about enabling preview images
                col = vis_box.column(align=True)
                col.label(text="Enable 'Download Preview", icon='INFO')
                col.label(text="Images' in GCS settings")
                col.label(text="to use this feature")

        # ================================================================
        # TEXT GENERATION CATEGORY (Collapsible)
        # ================================================================
        layout.separator()
        text_box = layout.box()
        text_header = text_box.row(align=True)
        text_icon = 'TRIA_DOWN' if style_props.show_text_generation else 'TRIA_RIGHT'
        text_header.prop(style_props, "show_text_generation", text="Text Generation", icon=text_icon, emboss=False, toggle=True)
        text_header.label(text="", icon='TEXT')
        
        if style_props.show_text_generation:
            # Refine Prompt - main action (largest button)
            row = text_box.row()
            row.scale_y = 2.0
            row.operator("style_engine.refine_prompt", text="Refine Prompt", icon='SORTALPHA')
            
            text_box.separator()
            
            # Other text generation actions (smaller buttons)
            col = text_box.column(align=True)
            col.scale_y = 1.2
            col.operator("style_engine.generate_image_description", text="Describe Current Image", icon='FILE_TEXT')
            col.operator("style_engine.generate_image_description_from_file", text="Describe Image from File", icon='FILEBROWSER')
            col.operator("style_engine.generate_image_description_from_viewport", text="Describe Viewport", icon='VIEW_CAMERA')
            
            # Prompt Browser
            text_box.separator()
            col = text_box.column(align=True)
            col.label(text="Prompt Browser:", icon='BOOKMARKS')
            
            # Get prompt history info
            from . import workspace_setup
            prompts = workspace_setup.get_prompt_list(context)
            
            if prompts:
                # Navigation buttons
                row = col.row(align=True)
                row.scale_y = 1.2
                
                # Check if at boundaries
                at_oldest = (style_props.current_prompt_index == 0)
                at_latest = (style_props.current_prompt_index == -1)
                
                # Previous button (go to older)
                prev_row = row.row(align=True)
                prev_row.enabled = not at_oldest
                prev_row.operator("style_engine.prev_prompt", text="", icon='TRIA_LEFT')
                
                # Current prompt indicator
                if at_latest:
                    current_text = f"Latest ({len(prompts)})"
                else:
                    current_text = f"{style_props.current_prompt_index + 1}/{len(prompts)}"
                
                row.label(text=current_text)
                
                # Next button (go to newer)
                next_row = row.row(align=True)
                next_row.enabled = not at_latest
                next_row.operator("style_engine.next_prompt", text="", icon='TRIA_RIGHT')
            else:
                col.label(text="No prompt history yet", icon='INFO')
            
            # # Helper text box - COMMENTED OUT FOR MINIMAL UI
            # prompt_box.separator()
            # help_box = prompt_box.box()
            # help_box.scale_y = 0.8
            # col = help_box.column(align=True)
            # col.label(text="Available templates loaded in text editor:", icon='TEXT')
            # col.label(text="• STYLEENGINE_Cinematic_Scene")
            # col.label(text="• STYLEENGINE_Fantasy_Dragon")
            # col.label(text="• STYLEENGINE_Portrait_Photo")
            # col.label(text="• (+ your custom templates)")
            # col.separator()
            # col.label(text="Use tags in STYLEENGINE_Prompt:", icon='INFO')
            # col.label(text="<subject> <style> <details> <environment>")
            # col.label(text="<mood> <camera> <lighting> <negative_prompt>")

        # # --- Server Status Indicator (TOP) --- COMMENTED OUT
        # status_box = layout.box()
        # row = status_box.row()
        # row.label(text="Server:", icon='WORLD')
        # 
        # # Get server status from poller
        # try:
        #     from . import runcomfy_polling
        #     server_status = runcomfy_polling.RunComfyPoller.get_server_status()
        #     
        #     status_icons = {
        #         'Idle': 'CHECKMARK',
        #         'Queued': 'TIME',
        #         'Active': 'CHECKMARK',
        #         'Generating': 'RENDER_ANIMATION'
        #     }
        #     row.label(text=server_status, icon=status_icons.get(server_status, 'QUESTION'))
        #     
        #     # Show active requests details if any
        #     if runcomfy_polling.RunComfyPoller.active_requests:
        #         for request_id, state in runcomfy_polling.RunComfyPoller.active_requests.items():
        #             row = status_box.row()
        #             import time
        #             elapsed = int(time.time() - state.start_time)
        #             row.label(text=f"  {state.workflow_type}: {elapsed}s", icon='DOT')
        #             
        #             # Cancel button
        #             cancel_op = row.operator("style_engine.cancel_generation", text="", icon='X')
        #             cancel_op.request_id = request_id
        # except Exception as e:
        #     row.label(text="Error", icon='ERROR')
        
        # # --- Workspace Setup - COLLAPSIBLE --- COMMENTED OUT
        # layout.separator()
        # setup_box = layout.box()
        # header_row = setup_box.row(align=True)
        # icon = 'TRIA_DOWN' if style_props.show_workspace_setup else 'TRIA_RIGHT'
        # header_row.prop(style_props, "show_workspace_setup", text="Workspace Setup", icon=icon, emboss=False, toggle=True)
        # 
        # if style_props.show_workspace_setup:
        #     setup_box.operator("style_engine.setup_workspace", icon='WINDOW')
        #     
        #     # Show camera reposition button if AI camera exists
        #     prefs = context.preferences.addons['styleengine'].preferences
        #     camera_name = prefs.camera_name_override
        #     if camera_name in bpy.data.objects:
        #         setup_box.operator("style_engine.align_camera_to_view", 
        #                            text="Reposition AI Camera", 
        #                            icon='VIEW_CAMERA')
        #     
        #     # Resolution dropdown (moved up)
        #     setup_box.separator()
        #     setup_box.label(text="Set Resolution:")
        #     setup_box.prop(style_props, "ai_resolution", text="")
        #     
        #     # Background opacity slider
        #     setup_box.separator()
        #     setup_box.label(text="Background Opacity:")
        #     setup_box.prop(style_props, "background_opacity", slider=True, text="")
        #     
        #     # Background depth control buttons
        #     prefs = context.preferences.addons['styleengine'].preferences
        #     camera_name = prefs.camera_name_override
        #     if camera_name in bpy.data.objects:
        #         depth_row = setup_box.row(align=True)
        #         depth_row.operator("style_engine.bring_background_forward", icon='TRIA_UP')
        #         depth_row.operator("style_engine.send_background_back", icon='TRIA_DOWN')
        #     
        #     # Output path
        #     setup_box.separator()
        #     setup_box.label(text="Output Path:")
        #     setup_box.prop(style_props, "output_path", text="")
        #     
        #     # Save Iterations checkbox (moved to bottom)
        #     setup_box.separator()
        #     setup_box.prop(style_props, "save_iterations", icon='FILE_TICK')
        
        # # --- Image Generation - COLLAPSIBLE --- COMMENTED OUT
        # layout.separator()
        # gen_box = layout.box()
        # header_row = gen_box.row(align=True)
        # icon = 'TRIA_DOWN' if style_props.show_image_generation else 'TRIA_RIGHT'
        # header_row.prop(style_props, "show_image_generation", text="Image Generation", icon=icon, emboss=False, toggle=True)
        # 
        # if style_props.show_image_generation:
        #     # # Lookup - COMMENTED OUT
        #     # gen_box.separator()
        #     # col = gen_box.column(align=True)
        #     # col.label(text="Lookup:")
        #     # col.prop(style_props, "lookup", text="")
        #     
        #     # # Global Prompt - COMMENTED OUT (now using text editor)
        #     # gen_box.separator()
        #     # col = gen_box.column(align=True)
        #     # 
        #     # # Info: Text editor is in workspace layout (bottom-right)
        #     # info_row = col.row(align=True)
        #     # info_row.label(text="Prompt (auto-syncs from text editor below camera)", icon='INFO')
        #     # 
        #     # col.separator()
        #     # 
        #     # # Quick view/edit (read-only preview of what will be used)
        #     # col.label(text="Current Prompt:", icon='TEXT')
        #     # col.prop(style_props, "global_prompt", text="")
        #     
        #     # Steps
        #     gen_box.separator()
        #     col = gen_box.column(align=True)
        #     col.label(text="Steps:")
        #     col.prop(style_props, "steps", slider=True, text="")
        #     
        #     # Influence section
        #     gen_box.separator()
        #     influence_box = gen_box.box()
        #     influence_box.label(text="Influence", icon='SHADERFX')
        #     influence_box.prop(style_props, "depth_influence", slider=True)
        #     influence_box.prop(style_props, "silhouette_influence", slider=True)
        #     
        #     # Image Reference section - COLLAPSIBLE
        #     gen_box.separator()
        #     ipadapter_box = gen_box.box()
        #     header_row = ipadapter_box.row(align=True)
        #     icon = 'TRIA_DOWN' if style_props.show_ipadapter else 'TRIA_RIGHT'
        #     header_row.prop(style_props, "show_ipadapter", text="Image Reference", icon=icon, emboss=False, toggle=True)
        #     
        #     if style_props.show_ipadapter:
        #         # Enable checkbox
        #         ipadapter_box.prop(style_props, "use_ipadapter", icon='IMAGE_DATA')
        #         
        #         # Only show controls if enabled
        #         if style_props.use_ipadapter:
        #             ipadapter_box.separator()
        #             
        #             # Reference image file picker
        #             col = ipadapter_box.column(align=True)
        #             col.label(text="Reference Image:")
        #             col.prop(style_props, "ipadapter_reference_image", text="")
        #             
        #             # Show filename if set
        #             if style_props.ipadapter_reference_image:
        #                 import os
        #                 filename = os.path.basename(style_props.ipadapter_reference_image)
        #                 col.label(text=f"📷 {filename}", icon='NONE')
        #             
        #             ipadapter_box.separator()
        #             
        #             # Weight type dropdown
        #             ipadapter_box.label(text="Mode:")
        #             ipadapter_box.prop(style_props, "ipadapter_weight_type", text="")
        #             
        #             ipadapter_box.separator()
        #             
        #             # Strength slider
        #             ipadapter_box.label(text="Strength:")
        #             ipadapter_box.prop(style_props, "ipadapter_strength", slider=True, text="")
        #             col = ipadapter_box.column(align=True)
        #             col.scale_y = 0.7
        #             col.label(text="(0.0 = Off, 5.0 = Max)")
        #     
        #     # Project Texture button
        #     gen_box.separator()
        #     gen_box.operator("style_engine.project_texture", icon='UV')
        #     
        #     # Generate Image - ONE-SHOT BUTTON (large, on top)
        #     gen_box.separator()
        #     gen_box.separator()
        #     gen_row = gen_box.row()
        #     gen_row.scale_y = 2.5  # Make it BIG
        #     gen_row.operator("style_engine.generate_ai_quick", text="Generate Image", icon='IMAGE_DATA')
        #     
        #     # Autogenerate - CONTINUOUS TOGGLE (smaller, below)
        #     gen_box.separator()
        #     gen_row = gen_box.row()
        #     gen_row.scale_y = 1.5  # Smaller than main button
        #     gen_row.prop(style_props, "auto_generate", text="Autogenerate", icon='FILE_REFRESH', toggle=True)
        #     
        #     # # Groups section - COMMENTED OUT FOR NOW
        #     # gen_box.separator()
        #     # groups_box = gen_box.box()
        #     # row = groups_box.row(align=True)
        #     #
        #     # icon = 'TRIA_DOWN' if style_props.show_groups else 'TRIA_RIGHT'
        #     # row.prop(style_props, "show_groups", text="Groups", icon=icon, emboss=False)
        #     #
        #     # if style_props.show_groups:
        #     #     # Group controls
        #     #     control_row = groups_box.row(align=True)
        #     #     control_row.operator("style_engine.add_group", icon='ADD', text="Add")
        #     #     control_row.operator("style_engine.assign_group", icon='LINK_BLEND', text="Assign")
        #     #     control_row.operator("style_engine.rename_group", icon='GREASEPENCIL', text="Rename")
        #     #     control_row.operator("style_engine.delete_group", icon='TRASH', text="Delete")
        #     #     
        #     #     groups_box.separator()
        #     #     
        #     #     # Show message if no groups
        #     #     if len(style_props.object_groups) == 0:
        #     #         groups_box.label(text="No groups. Click 'Add' to create one.", icon='INFO')
        #     #     else:
        #     #         # Dynamic groups display
        #     #         header = groups_box.row()
        #     #         header.label(text="")  # Selection column
        #     #         header.label(text="Group Name")
        #     #         header.label(text="Keywords")
        #     #         
        #     #         # Display all groups dynamically
        #     #         for idx, group in enumerate(style_props.object_groups):
        #     #             row = groups_box.row(align=True)
        #     #             
        #     #             # Selection radio button
        #     #             selected = style_props.active_group_index == idx
        #     #             row.operator("style_engine.select_group", text="", icon='RADIOBUT_ON' if selected else 'RADIOBUT_OFF', emboss=False).group_index = idx
        #     #             
        #     #             # Group name
        #     #             row.label(text=group.name.upper())
        #     #             
        #     #             # Keywords input
        #     #             row.prop(group, "keywords", text="")
        
        # ================================================================
        # IMAGE GENERATION CATEGORY (Collapsible)
        # ================================================================
        layout.separator()
        img_gen_box = layout.box()
        img_gen_header = img_gen_box.row(align=True)
        img_gen_icon = 'TRIA_DOWN' if style_props.show_image_generation_main else 'TRIA_RIGHT'
        img_gen_header.prop(style_props, "show_image_generation_main", text="Image Generation", icon=img_gen_icon, emboss=False, toggle=True)
        img_gen_header.label(text="", icon='IMAGE_DATA')
        
        if style_props.show_image_generation_main:
            # Generate Image button (main action)
            row = img_gen_box.row()
            row.scale_y = 2.0
            row.operator("style_engine.generate_ai_quick", 
                         text="Generate Image", 
                         icon='IMAGE_DATA')
            
            img_gen_box.separator()
            
            # ────────────────────────────────────────────────────────────
            # INFLUENCE SUB-CATEGORY (Collapsible)
            # ────────────────────────────────────────────────────────────
            influence_box = img_gen_box.box()
            influence_header = influence_box.row(align=True)
            influence_icon = 'TRIA_DOWN' if style_props.show_influence else 'TRIA_RIGHT'
            influence_header.prop(style_props, "show_influence", text="Influence", icon=influence_icon, emboss=False, toggle=True)
            influence_header.label(text="", icon='SMOOTHCURVE')
            
            if style_props.show_influence:
                col = influence_box.column(align=True)
                col.prop(style_props, "silhouette_influence", text="Silhouette", slider=True)
                col.prop(style_props, "depth_influence", text="Depth", slider=True)
                col.prop(style_props, "texture_influence", text="Viewport", slider=True)
                
                influence_box.separator()
                col = influence_box.column(align=True)
                col.label(text="Steps:")
                col.prop(style_props, "steps", text="", slider=True)
            
            # Autogenerate toggle - HIDDEN (now redundant with progress bar)
            # img_gen_box.separator()
            # row = img_gen_box.row()
            # row.scale_y = 1.3
            # row.prop(style_props, "auto_generate", 
            #          text="Autogenerate", 
            #          toggle=True, 
            #          icon='FILE_REFRESH')
            
            # ────────────────────────────────────────────────────────────
            # REFERENCE IMAGES SUB-CATEGORY (Collapsible, closed by default)
            # ────────────────────────────────────────────────────────────
            img_gen_box.separator()
            ref_box = img_gen_box.box()
            ref_header = ref_box.row(align=True)
            ref_icon = 'TRIA_DOWN' if style_props.show_reference_images else 'TRIA_RIGHT'
            ref_header.prop(style_props, "show_reference_images", text="Reference Images", icon=ref_icon, emboss=False, toggle=True)
            ref_header.label(text="", icon='IMAGE_REFERENCE')
            
            if style_props.show_reference_images:
                # Advanced Control toggle (shows individual weight sliders when enabled)
                adv_row = ref_box.row(align=True)
                adv_row.prop(style_props, "show_advanced_ref_controls", text="Advanced Control", toggle=True, icon='PREFERENCES')
                
                # Helper function to draw a reference image section
                def draw_reference_section(box, title, icon, show_prop, slots, strength_prop, show_weights=False):
                    """Draw a collapsible reference image section with grid layout"""
                    section_box = box.box()
                    header = section_box.row(align=True)
                    icon_tri = 'TRIA_DOWN' if getattr(style_props, show_prop) else 'TRIA_RIGHT'
                    header.prop(style_props, show_prop, text=title, icon=icon_tri, emboss=False, toggle=True)
                
                    if getattr(style_props, show_prop):
                        # Global strength slider
                        section_box.separator()
                        strength_row = section_box.row()
                        strength_row.scale_y = 1.5
                        strength_row.prop(style_props, strength_prop, text="Global Strength", slider=True)
                        
                        section_box.separator()
                        
                        # Grid layout for images (3 columns)
                        grid = section_box.grid_flow(
                            row_major=True,
                            columns=3,
                            even_columns=True,
                            even_rows=True,
                            align=True
                        )
                        
                        # Draw each slot
                        for slot_id, img_prop, weight_prop, label in slots:
                            img = getattr(style_props, img_prop)
                        
                            # Card for each slot
                            card = grid.box()
                            card.scale_y = 1.0
                            
                            if img:
                                # Image exists - show preview and controls
                                col = card.column(align=True)
                        
                                # Image thumbnail using template_icon
                                # This displays the actual image content as an icon
                                preview_box = col.box()
                                preview_col = preview_box.column(align=True)
                                
                                # Display image thumbnail using preview collection (Poliigon method)
                                try:
                                    # Get the persistent preview collection
                                    pcoll = preview_collections.get("ref_images")
                                    
                                    if pcoll is None:
                                        preview_col.label(text="[No Collection]", icon='ERROR')
                                    else:
                                        # Generate unique key for this image
                                        thumb_key = f"{slot_id}_{img.name}"
                                        
                                        # Load thumbnail into preview collection if not already loaded
                                        if thumb_key not in pcoll:
                                            if img.filepath:
                                                abs_path = bpy.path.abspath(img.filepath)
                                                try:
                                                    pcoll.load(thumb_key, abs_path, 'IMAGE')
                                                except Exception as e:
                                                    print(f"[UI] Failed to load preview for {img.name}: {e}")
                                        
                                        # Display the thumbnail using template_icon
                                        if thumb_key in pcoll:
                                            thumb = pcoll[thumb_key]
                                            if thumb.icon_id > 0:
                                                preview_col.template_icon(icon_value=thumb.icon_id, scale=5.0)
                                            else:
                                                preview_col.label(text="[Invalid Icon]", icon='IMAGE_DATA')
                                        else:
                                            preview_col.label(text="[Not Loaded]", icon='IMAGE_DATA')
                                    
                                except Exception as e:
                                    preview_col.label(text="[Error]", icon='ERROR')
                                    print(f"[UI] Error displaying thumbnail for {img.name}: {e}")
                                
                                col.separator(factor=0.2)
                            
                                # Slot label and image name
                                info_col = col.column(align=True)
                                info_col.scale_y = 0.7
                                
                                label_row = info_col.row()
                                label_row.alignment = 'CENTER'
                                label_row.label(text=label, icon='IMAGE_DATA')
                                
                                name_row = info_col.row()
                                name_row.alignment = 'CENTER'
                                display_name = img.name[:10] + "..." if len(img.name) > 13 else img.name
                                name_row.label(text=display_name)
                                
                                col.separator(factor=0.3)
                            
                                # Weight slider (only shown when Advanced Control is enabled)
                                if show_weights:
                                    col.prop(style_props, weight_prop, text="", slider=True)
                                    col.separator(factor=0.2)
                            
                                # Action buttons (reload and clear)
                                btn_row = col.row(align=True)
                                btn_row.scale_y = 0.7
                                reload_op = btn_row.operator("style_engine.reload_reference", text="", icon='FILE_REFRESH')
                                reload_op.slot = slot_id
                                clear_op = btn_row.operator("style_engine.clear_reference", text="", icon='X')
                                clear_op.slot = slot_id
                            else:
                                # Empty slot - show add button
                                col = card.column(align=True)
                                col.scale_y = 2.5
                                col.separator()
                                load_op = col.operator("style_engine.load_reference", 
                                                     text=f"{label}\n+", 
                                                     icon='ADD',
                                                     emboss=True)
                                load_op.slot = slot_id
                                col.separator()
                
                # Style Transfer section
                st_slots = [
                    ("st1", "st1_image", "st1_weight", "ST1"),
                    ("st2", "st2_image", "st2_weight", "ST2"),
                    ("st3", "st3_image", "st3_weight", "ST3"),
                    ("st4", "st4_image", "st4_weight", "ST4"),
                    ("st5", "st5_image", "st5_weight", "ST5"),
                ]
                draw_reference_section(ref_box, "Style", 'BRUSH_DATA', 
                                     "show_style_transfer", st_slots, "style_transfer_strength",
                                     show_weights=style_props.show_advanced_ref_controls)
                
                # Composition section
                comp_slots = [
                    ("comp1", "comp1_image", "comp1_weight", "COMP1"),
                    ("comp2", "comp2_image", "comp2_weight", "COMP2"),
                    ("comp3", "comp3_image", "comp3_weight", "COMP3"),
                    ("comp4", "comp4_image", "comp4_weight", "COMP4"),
                    ("comp5", "comp5_image", "comp5_weight", "COMP5"),
                ]
                draw_reference_section(ref_box, "Composition", 'MESH_GRID', 
                                     "show_composition", comp_slots, "composition_strength",
                                     show_weights=style_props.show_advanced_ref_controls)
            
            # ────────────────────────────────────────────────────────────
            # LORAS SUB-CATEGORY (Collapsible, closed by default)
            # ────────────────────────────────────────────────────────────
            img_gen_box.separator()
            lora_box = img_gen_box.box()
            lora_header = lora_box.row(align=True)
            lora_icon = 'TRIA_DOWN' if style_props.show_loras else 'TRIA_RIGHT'
            lora_header.prop(style_props, "show_loras", text="LoRas", icon=lora_icon, emboss=False, toggle=True)
            lora_header.label(text="", icon='MODIFIER')
            
            if style_props.show_loras:
                lora_col = lora_box.column(align=False)
                
                # ── LoRa 1 ──────────────────────────────────
                lora1_box = lora_col.box()
                lora1_col = lora1_box.column(align=True)
                
                # Enable toggle (prominent)
                row = lora1_col.row()
                row.scale_y = 1.4
                row.prop(style_props, "lora_enabled", 
                              text="Use LoRa", 
                              toggle=True, icon='MODIFIER')
                
                # Only show controls if enabled
                if style_props.lora_enabled:
                    lora1_col.separator(factor=0.3)
                    
                    # LoRa dropdown with refresh button
                    refresh_row = lora1_col.row(align=True)
                    refresh_row.prop(style_props, "lora_name", text="")
                    refresh_row.operator("style_engine.refresh_lora_list", text="", icon='FILE_REFRESH')
                    
                    # Strength slider
                    lora1_col.prop(style_props, "lora_strength_model", 
                                  text="Strength", 
                                  slider=True)
                
                # ── LoRa 2 ──────────────────────────────────
                lora2_box = lora_col.box()
                lora2_col = lora2_box.column(align=True)
                
                lora2_col.prop(style_props, "lora2_enabled", text="Use LoRa 2", toggle=True, icon='MODIFIER')
                
                # Show LoRa 2 controls if enabled
                if style_props.lora2_enabled:
                    lora2_col.separator(factor=0.3)
                    
                    # LoRa 2 dropdown
                    lora2_col.prop(style_props, "lora2_name", text="")
                    
                    # LoRa 2 Strength
                    lora2_col.prop(style_props, "lora2_strength_model", text="Strength", slider=True)
                
                # ── Load Keywords Button ────────────────────
                lora_col.separator(factor=0.3)
                lora_col.operator("style_engine.load_lora_keywords", text="Load Keywords", icon='TEXT')
                
                # Show active LoRas summary
                active_loras = []
                if style_props.lora_enabled and style_props.lora_name != 'NONE':
                    active_loras.append(f"L1: {style_props.lora_name.replace('.safetensors', '')[:12]}")
                if style_props.lora2_enabled and style_props.lora2_name != 'NONE':
                    active_loras.append(f"L2: {style_props.lora2_name.replace('.safetensors', '')[:12]}")
                
                if active_loras:
                    info_row = lora_col.row()
                    info_row.scale_y = 0.7
                    info_row.label(text=", ".join(active_loras), icon='CHECKMARK')
            
            # ────────────────────────────────────────────────────────────
            # PROJECT TEXTURE & PBR BUTTONS
            # ────────────────────────────────────────────────────────────
            img_gen_box.separator()
            row = img_gen_box.row()
            row.scale_y = 1.3
            row.operator("style_engine.project_texture", text="Project Texture", icon='UV')
            
            # PBR from Projected Texture (conditional: only when active mesh has iteration_XXX material)
            obj = context.active_object
            has_iteration_mat = (
                obj and obj.type == 'MESH' and obj.data.materials and
                any(m and m.name.startswith('iteration_') for m in obj.data.materials)
            )
            if has_iteration_mat:
                row = img_gen_box.row()
                row.scale_y = 1.2
                row.operator("style_engine.pbr_from_projected", text="PBR from Projected Texture", icon='MATSHADERBALL')
            
            # Generate PBR Material from text (always visible)
            row = img_gen_box.row()
            row.scale_y = 1.2
            row.operator("style_engine.pbr_from_text", text="Generate PBR Material", icon='MATSHADERBALL')
        
        # ================================================================
        # 3D GENERATION CATEGORY (Collapsible)
        # ================================================================
        layout.separator()
        gen3d_box = layout.box()
        gen3d_header = gen3d_box.row(align=True)
        gen3d_icon = 'TRIA_DOWN' if style_props.show_3d_generation else 'TRIA_RIGHT'
        gen3d_header.prop(style_props, "show_3d_generation", text="3D Generation", icon=gen3d_icon, emboss=False, toggle=True)
        gen3d_header.label(text="", icon='MESH_CUBE')
        
        if style_props.show_3d_generation:
            # 3D Quality selector
            col = gen3d_box.column(align=True)
            col.label(text="3D Quality:")
            col.prop(style_props, "object_quality", text="")
            
            gen3d_box.separator()
            
            # ────────────────────────────────────────────────────────────
            # 3D FROM SINGLE IMAGE SUB-CATEGORY (Collapsible)
            # ────────────────────────────────────────────────────────────
            single_box = gen3d_box.box()
            single_header = single_box.row(align=True)
            single_icon = 'TRIA_DOWN' if style_props.show_3d_single_image else 'TRIA_RIGHT'
            single_header.prop(style_props, "show_3d_single_image", text="3D from Single Image", icon=single_icon, emboss=False, toggle=True)
            single_header.label(text="", icon='IMAGE_DATA')
            
            if style_props.show_3d_single_image:
                col = single_box.column(align=True)
                col.scale_y = 1.2
                col.operator("style_engine.create_object", text="Generate Mesh", icon='MESH_UVSPHERE')
                col.operator("style_engine.create_textured_object", text="Generate Textured Mesh", icon='SHADING_TEXTURE')
            
            # ────────────────────────────────────────────────────────────
            # 3D FROM MULTIVIEW SUB-CATEGORY (Collapsible, closed by default)
            # ────────────────────────────────────────────────────────────
            gen3d_box.separator()
            multi_box = gen3d_box.box()
            multi_header = multi_box.row(align=True)
            multi_icon = 'TRIA_DOWN' if style_props.show_3d_multiview else 'TRIA_RIGHT'
            multi_header.prop(style_props, "show_3d_multiview", text="3D from Multiview", icon=multi_icon, emboss=False, toggle=True)
            multi_header.label(text="", icon='VIEW_ORTHO')
            
            if style_props.show_3d_multiview:
                col = multi_box.column(align=True)
                col.scale_y = 1.2
                col.operator("style_engine.generate_mesh_multiview", text="Generate Mesh", icon='MESH_UVSPHERE')
                col.operator("style_engine.generate_textured_mesh_multiview", text="Generate Textured Mesh", icon='SHADING_TEXTURE')
            
            # ────────────────────────────────────────────────────────────
            # MODEL BROWSER
            # ────────────────────────────────────────────────────────────
            gen3d_box.separator()
            col = gen3d_box.column(align=True)
            col.label(text="Model Browser:", icon='FILE_3D')
            
            # Get model library info
            from . import workspace_setup
            models = workspace_setup.get_model_list(context)
            
            if models:
                # Navigation buttons
                row = col.row(align=True)
                row.scale_y = 1.2
                
                # Check if at boundaries
                at_oldest = (style_props.current_model_index == 0)
                at_latest = (style_props.current_model_index == -1)
                
                # Previous button (go to older)
                prev_row = row.row(align=True)
                prev_row.enabled = not at_oldest
                prev_row.operator("style_engine.prev_model", text="", icon='TRIA_LEFT')
                
                # Current model indicator
                if at_latest:
                    current_text = f"Latest ({len(models)})"
                else:
                    current_text = f"{style_props.current_model_index + 1}/{len(models)}"
                
                row.label(text=current_text)
                
                # Next button (go to newer)
                next_row = row.row(align=True)
                next_row.enabled = not at_latest
                next_row.operator("style_engine.next_model", text="", icon='TRIA_RIGHT')
                
                # Spawn button
                col.separator()
                spawn_row = col.row(align=True)
                spawn_row.scale_y = 1.3
                spawn_row.operator("style_engine.spawn_model", text="Spawn Model", icon='IMPORT')
            else:
                col.label(text="No models yet", icon='INFO')
        
        # # --- Settings - COLLAPSIBLE --- COMMENTED OUT
        # layout.separator()
        # settings_box = layout.box()
        # header_row = settings_box.row(align=True)
        # icon = 'TRIA_DOWN' if style_props.show_settings else 'TRIA_RIGHT'
        # header_row.prop(style_props, "show_settings", text="Settings", icon=icon, emboss=False, toggle=True)
        # 
        # if style_props.show_settings:
        #     # Test Workflow button (formerly Generate Cloud, moved from Image Generation)
        #     settings_box.operator("style_engine.test_cloud_generation", text="Test Workflow", icon='EXPERIMENTAL')
        #     
        #     settings_box.separator()
        #     settings_box.label(text="(Advanced settings in addon preferences)", icon='INFO')

        # Legacy action buttons removed (Visualize, Create 3D, Render)


# ----------------------------------------------------------------
# 3.5 PROMPT REFINEMENT OPERATOR
# ----------------------------------------------------------------

def _extract_text_from_griptape_output(outputs):
    """
    Helper function to extract text from Griptape workflow outputs.
    Tries multiple node IDs and output formats.
    
    Returns:
        str: Extracted text or None if not found
    """
    refined_text = None
    
    # Try node 17 first (Griptape Run: Agent)
    if "17" in outputs:
        node_17_output = outputs["17"]
        if isinstance(node_17_output, dict) and "string" in node_17_output:
            refined_text = node_17_output["string"][0] if isinstance(node_17_output["string"], list) else node_17_output["string"]
        elif isinstance(node_17_output, list) and len(node_17_output) > 0:
            refined_text = node_17_output[0]
    
    # Try node 19 if node 17 didn't work (Griptape Display: Text)
    if not refined_text and "19" in outputs:
        node_19_output = outputs["19"]
        if isinstance(node_19_output, dict):
            # Try common keys
            for key in ["string", "text", "STRING", "INPUT"]:
                if key in node_19_output:
                    val = node_19_output[key]
                    if isinstance(val, list) and len(val) > 0:
                        # Check if list of characters - join them
                        if all(isinstance(c, str) and len(c) <= 1 for c in val[:10]):
                            refined_text = ''.join(val)
                        else:
                            refined_text = val[0]
                    elif isinstance(val, str):
                        refined_text = val
                    if refined_text:
                        break
            # Try getting any string value
            if not refined_text:
                for key, value in node_19_output.items():
                    if isinstance(value, str) and len(value) > 10:
                        refined_text = value
                        break
                    elif isinstance(value, list) and len(value) > 0:
                        if all(isinstance(c, str) and len(c) <= 1 for c in value[:10]):
                            refined_text = ''.join(value)
                            break
                        elif isinstance(value[0], str):
                            refined_text = value[0]
                            break
        elif isinstance(node_19_output, list) and len(node_19_output) > 0:
            refined_text = node_19_output[0]
        elif isinstance(node_19_output, str):
            refined_text = node_19_output
    
    # Try node 20 (fallback)
    if not refined_text and "20" in outputs:
        node_20_output = outputs["20"]
        if isinstance(node_20_output, dict) and "string" in node_20_output:
            refined_text = node_20_output["string"][0] if isinstance(node_20_output["string"], list) else node_20_output["string"]
        elif isinstance(node_20_output, str):
            refined_text = node_20_output
    
    return refined_text.strip() if refined_text else None


class WM_OT_RefinePrompt(bpy.types.Operator):
    """Use local LLM to refine the prompt text (extracts <p> content, enhances it, and updates the text editor)"""
    bl_idname = "style_engine.refine_prompt"
    bl_label = "Refine Prompt (LLM)"
    bl_description = "Use local LLM to enhance the main prompt (<p> tag)"
    
    def execute(self, context):
        import re
        import json
        from pathlib import Path
        from . import runcomfy_deployment
        
        # 1. Get text editor content
        text_block = bpy.data.texts.get("STYLEENGINE_Prompt")
        if not text_block:
            self.report({'ERROR'}, "STYLEENGINE_Prompt text block not found")
            return {'CANCELLED'}
        
        current_content = text_block.as_string()
        
        # 2. Extract <p> content
        p_match = re.search(r'<p>(.*?)</p>', current_content, re.DOTALL | re.IGNORECASE)
        if not p_match:
            self.report({'ERROR'}, "No <p> tag found in prompt text")
            print("[Refine Prompt] No <p> tag found in text editor")
            return {'CANCELLED'}
        
        original_prompt = p_match.group(1).strip()
        if not original_prompt:
            self.report({'ERROR'}, "<p> tag is empty")
            print("[Refine Prompt] <p> tag is empty")
            return {'CANCELLED'}
        
        print(f"[Refine Prompt] Original prompt: {original_prompt}")
        
        # Save "before" snapshot
        from . import workspace_setup
        workspace_setup.save_prompt_snapshot(context, prefix="before_refine")
        
        # 3. Check if in Server mode (GCS)
        if not runcomfy_deployment.is_server_mode():
            self.report({'ERROR'}, "Prompt refinement only works in Server mode (GCS)")
            print("[Refine Prompt] ❌ Not in Server mode - feature requires direct ComfyUI connection")
            return {'CANCELLED'}
        
        try:
            # 4. Load TextRefine.json workflow
            addon_dir = Path(__file__).parent
            workflow_file = addon_dir / "workflows" / "Text" / "TextRefine.json"
            
            if not workflow_file.exists():
                self.report({'ERROR'}, "TextRefine.json not found")
                print(f"[Refine Prompt] ❌ Workflow not found: {workflow_file}")
                return {'CANCELLED'}
            
            with open(workflow_file, 'r') as f:
                workflow = json.load(f)
            
            print(f"[Refine Prompt] ✓ Loaded workflow: {workflow_file.name}")
            
            # 5. Patch node 7 with the original prompt text
            if "7" not in workflow:
                self.report({'ERROR'}, "Invalid workflow structure (node 7 missing)")
                print("[Refine Prompt] ❌ Node 7 not found in workflow")
                return {'CANCELLED'}
            
            workflow["7"]["inputs"]["text"] = original_prompt
            print(f"[Refine Prompt] ✓ Patched node 7 with prompt text")
            
            # 6. Submit to ComfyUI server
            server_client = runcomfy_deployment.get_server_client()
            
            print(f"[Refine Prompt] Submitting to ComfyUI server...")
            response = server_client.queue_prompt(workflow)
            prompt_id = response['prompt_id']
            print(f"[Refine Prompt] ✓ Queued prompt refinement (ID: {prompt_id[:8]}...)")
            
            # Store workflow for progress bar node name lookup
            from . import progress_bar
            progress_bar.set_current_workflow(workflow)
            
            # 7. Start NON-BLOCKING polling with callback
            from . import runcomfy_polling
            
            def on_refine_complete(success, result=None, error=None, workflow_type=None):
                """Callback when refinement completes"""
                print(f"[Refine Prompt] Callback triggered: success={success}")
                
                if not success:
                    print(f"[Refine Prompt] ❌ Failed: {error}")
                    return
                
                try:
                    # Extract outputs
                    outputs = result.get('outputs', {})
                    
                    # Extract refined text using helper
                    refined_text = _extract_text_from_griptape_output(outputs)
                    
                    if not refined_text:
                        print(f"[Refine Prompt] ❌ No text output found")
                        print(f"[Refine Prompt] Available outputs: {list(outputs.keys())}")
                        return
                    
                    print(f"[Refine Prompt] ✓ Refined prompt: {refined_text[:100]}...")
                    
                    # Update text editor
                    text_block = bpy.data.texts.get("STYLEENGINE_Prompt")
                    if not text_block:
                        print("[Refine Prompt] ❌ Text block not found")
                        return
                    
                    current_content = text_block.as_string()
                    new_content = re.sub(
                        r'(<p>)(.*?)(</p>)',
                        r'\1' + refined_text + r'\3',
                        current_content,
                        flags=re.DOTALL | re.IGNORECASE
                    )
                    
                    text_block.clear()
                    text_block.write(new_content)
                    
                    # Save "after" snapshot
                    workspace_setup.save_prompt_snapshot(bpy.context, prefix="after_refine")
                    
                    print(f"[Refine Prompt] ✓ Updated text editor with refined prompt")
                    
                except Exception as e:
                    print(f"[Refine Prompt] ❌ Callback error: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Register for non-blocking polling
            runcomfy_polling.RunComfyPoller.start_polling(
                deployment_id='server',
                request_id=prompt_id,
                callback=on_refine_complete,
                workflow_type='text'
            )
            
            self.report({'INFO'}, "Refining prompt... (watch progress bar)")
            print(f"[Refine Prompt] ⏳ Processing in background...")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to refine prompt: {str(e)}")
            print(f"[Refine Prompt] ❌ Error: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}


class WM_OT_GenerateImageDescription(bpy.types.Operator):
    """Generate description from current AI image using machine vision"""
    bl_idname = "style_engine.generate_image_description"
    bl_label = "Generate Image Description"
    bl_description = "Use AI machine vision to generate a text description from current_ai.png"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        import re
        import json
        from pathlib import Path
        from . import runcomfy_deployment
        from . import workspace_setup
        
        # 1. Check if in Server mode (GCS)
        if not runcomfy_deployment.is_server_mode():
            self.report({'ERROR'}, "Image description only works in Server mode (GCS)")
            print("[Image Description] ❌ Not in Server mode - feature requires direct ComfyUI connection")
            return {'CANCELLED'}
        
        # 2. Get path to current_ai.png
        temp_dir = workspace_setup.get_temp_directory(context)
        image_path = temp_dir / "current_ai.png"
        
        if not image_path.exists():
            self.report({'ERROR'}, "current_ai.png not found - generate an image first")
            print(f"[Image Description] ❌ Image not found: {image_path}")
            return {'CANCELLED'}
        
        print(f"[Image Description] Using image: {image_path}")
        
        # Save "before" snapshot
        workspace_setup.save_prompt_snapshot(context, prefix="before_vision")
        
        try:
            # 3. Load TextImage.json workflow (vision-based image description)
            addon_dir = Path(__file__).parent
            workflow_file = addon_dir / "workflows" / "Text" / "TextImage.json"
            
            if not workflow_file.exists():
                self.report({'ERROR'}, "TextImage.json not found")
                print(f"[Image Description] ❌ Workflow not found: {workflow_file}")
                return {'CANCELLED'}
            
            with open(workflow_file, 'r') as f:
                workflow = json.load(f)
            
            print(f"[Image Description] ✓ Loaded workflow: {workflow_file.name}")
            
            # 4. Upload image to ComfyUI server
            server_client = runcomfy_deployment.get_server_client()
            
            print(f"[Image Description] Uploading image to ComfyUI server...")
            upload_response = server_client.upload_image(str(image_path), overwrite=True)
            uploaded_filename = upload_response.get("name", "")
            
            if not uploaded_filename:
                self.report({'ERROR'}, "Failed to upload image to server")
                print(f"[Image Description] ❌ Upload failed: {upload_response}")
                return {'CANCELLED'}
            
            print(f"[Image Description] ✓ Uploaded image: {uploaded_filename}")
            
            # 5. Patch node 23 (LoadImage) with the uploaded filename
            if "23" not in workflow:
                self.report({'ERROR'}, "Invalid workflow structure (node 23 missing)")
                print("[Image Description] ❌ Node 23 not found in workflow")
                return {'CANCELLED'}
            
            workflow["23"]["inputs"]["image"] = uploaded_filename
            print(f"[Image Description] ✓ Patched node 23 with image: {uploaded_filename}")
            
            # 6. Submit to ComfyUI server
            print(f"[Image Description] Submitting to ComfyUI server...")
            response = server_client.queue_prompt(workflow)
            prompt_id = response['prompt_id']
            print(f"[Image Description] ✓ Queued image description (ID: {prompt_id[:8]}...)")
            
            # Store workflow for progress bar node name lookup
            from . import progress_bar
            progress_bar.set_current_workflow(workflow)
            
            # 7. Start NON-BLOCKING polling with callback
            from . import runcomfy_polling
            
            def on_description_complete(success, result=None, error=None, workflow_type=None):
                """Callback when description completes"""
                print(f"[Image Description] Callback triggered: success={success}")
                
                if not success:
                    print(f"[Image Description] ❌ Failed: {error}")
                    return
                
                try:
                    # Extract outputs
                    outputs = result.get('outputs', {})
                    
                    # Extract description using helper
                    description_text = _extract_text_from_griptape_output(outputs)
                    
                    if not description_text:
                        print(f"[Image Description] ❌ No text output found")
                        return
                    
                    print(f"[Image Description] ✓ Generated: {description_text[:100]}...")
                    
                    # Update <v> tag in text editor
                    text_block = bpy.data.texts.get("STYLEENGINE_Prompt")
                    if not text_block:
                        print("[Image Description] ❌ Text block not found")
                        return
                    
                    current_content = text_block.as_string()
                    
                    # Check if <v> tag exists
                    if re.search(r'<v>.*?</v>', current_content, re.DOTALL | re.IGNORECASE):
                        # Replace existing <v> content
                        new_content = re.sub(
                            r'(<v>)(.*?)(</v>)',
                            r'\1' + description_text + r'\3',
                            current_content,
                            flags=re.DOTALL | re.IGNORECASE
                        )
                    else:
                        # Add <v> section at the end
                        new_content = current_content.rstrip() + "\n# Machine Vision\n<v>" + description_text + "</v>\n"
                    
                    # Update text block
                    text_block.clear()
                    text_block.write(new_content)
                    
                    # Save "after" snapshot
                    workspace_setup.save_prompt_snapshot(bpy.context, prefix="after_vision")
                    
                    print(f"[Image Description] ✓ Updated text editor with description")
                    
                except Exception as e:
                    print(f"[Image Description] ❌ Callback error: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Register for non-blocking polling
            runcomfy_polling.RunComfyPoller.start_polling(
                deployment_id='server',
                request_id=prompt_id,
                callback=on_description_complete,
                workflow_type='text'
            )
            
            self.report({'INFO'}, "Generating image description... (watch progress bar)")
            print(f"[Image Description] ⏳ Processing in background...")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Image description failed: {str(e)}")
            print(f"[Image Description] ❌ Exception: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}


class WM_OT_GenerateImageDescriptionFromFile(bpy.types.Operator):
    """Generate description from any image file using machine vision"""
    bl_idname = "style_engine.generate_image_description_from_file"
    bl_label = "Describe Image from File"
    bl_description = "Open file browser to select an image, then generate AI description and add to <v> tag"
    bl_options = {'REGISTER'}
    
    # File browser properties
    filepath: bpy.props.StringProperty(
        subtype='FILE_PATH',
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    
    filter_glob: bpy.props.StringProperty(
        default="*.jpg;*.jpeg;*.png",
        options={'HIDDEN'}
    )
    
    def invoke(self, context, event):
        # Open file browser
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        import re
        import json
        from pathlib import Path
        from . import runcomfy_deployment
        from . import workspace_setup
        
        # Validate filepath
        if not self.filepath:
            self.report({'ERROR'}, "No file selected")
            return {'CANCELLED'}
        
        image_path = Path(self.filepath)
        if not image_path.exists():
            self.report({'ERROR'}, f"File not found: {image_path}")
            return {'CANCELLED'}
        
        # Check file extension
        valid_extensions = {'.jpg', '.jpeg', '.png'}
        if image_path.suffix.lower() not in valid_extensions:
            self.report({'ERROR'}, f"Invalid file type. Use: {', '.join(valid_extensions)}")
            return {'CANCELLED'}
        
        # 1. Check if in Server mode (GCS)
        if not runcomfy_deployment.is_server_mode():
            self.report({'ERROR'}, "Image description only works in Server mode (GCS)")
            print("[Image Description] ❌ Not in Server mode - feature requires direct ComfyUI connection")
            return {'CANCELLED'}
        
        print(f"[Image Description from File] Using image: {image_path}")
        
        # Save "before" snapshot
        workspace_setup.save_prompt_snapshot(context, prefix="before_vision_file")
        
        try:
            # 2. Load TextImage.json workflow
            addon_dir = Path(__file__).parent
            workflow_file = addon_dir / "workflows" / "Text" / "TextImage.json"
            
            if not workflow_file.exists():
                self.report({'ERROR'}, "TextImage.json not found")
                print(f"[Image Description from File] ❌ Workflow not found: {workflow_file}")
                return {'CANCELLED'}
            
            with open(workflow_file, 'r') as f:
                workflow = json.load(f)
            
            print(f"[Image Description from File] ✓ Loaded workflow: {workflow_file.name}")
            
            # 3. Upload image to ComfyUI server
            server_client = runcomfy_deployment.get_server_client()
            
            print(f"[Image Description from File] Uploading image to ComfyUI server...")
            upload_response = server_client.upload_image(str(image_path), overwrite=True)
            uploaded_filename = upload_response.get("name", "")
            
            if not uploaded_filename:
                self.report({'ERROR'}, "Failed to upload image to server")
                print(f"[Image Description from File] ❌ Upload failed: {upload_response}")
                return {'CANCELLED'}
            
            print(f"[Image Description from File] ✓ Uploaded image: {uploaded_filename}")
            
            # 4. Patch node 23 (LoadImage) with the uploaded filename
            if "23" not in workflow:
                self.report({'ERROR'}, "Invalid workflow structure (node 23 missing)")
                print("[Image Description from File] ❌ Node 23 not found in workflow")
                return {'CANCELLED'}
            
            workflow["23"]["inputs"]["image"] = uploaded_filename
            print(f"[Image Description from File] ✓ Patched node 23 with image: {uploaded_filename}")
            
            # 5. Submit to ComfyUI server
            print(f"[Image Description from File] Submitting to ComfyUI server...")
            response = server_client.queue_prompt(workflow)
            prompt_id = response['prompt_id']
            print(f"[Image Description from File] ✓ Queued image description (ID: {prompt_id[:8]}...)")
            
            # Store workflow for progress bar node name lookup
            from . import progress_bar
            progress_bar.set_current_workflow(workflow)
            
            # 6. Start NON-BLOCKING polling with callback
            from . import runcomfy_polling
            
            # Capture image_path.name for callback
            image_name = image_path.name
            
            def on_description_complete(success, result=None, error=None, workflow_type=None):
                """Callback when description completes"""
                print(f"[Image Description from File] Callback triggered: success={success}")
                
                if not success:
                    print(f"[Image Description from File] ❌ Failed: {error}")
                    return
                
                try:
                    # Extract outputs
                    outputs = result.get('outputs', {})
                    
                    # Extract description using helper
                    description_text = _extract_text_from_griptape_output(outputs)
                    
                    if not description_text:
                        print(f"[Image Description from File] ❌ No text output found")
                        return
                    
                    print(f"[Image Description from File] ✓ Generated: {description_text[:100]}...")
                    
                    # APPEND to <v> tag in text editor (not replace!)
                    text_block = bpy.data.texts.get("STYLEENGINE_Prompt")
                    if not text_block:
                        print("[Image Description from File] ❌ Text block not found")
                        return
                    
                    current_content = text_block.as_string()
                    
                    # Check if <v> tag exists
                    v_match = re.search(r'<v>(.*?)</v>', current_content, re.DOTALL | re.IGNORECASE)
                    if v_match:
                        existing_v = v_match.group(1).strip()
                        if existing_v:
                            # Append to existing content with separator
                            new_v_content = existing_v + ". " + description_text
                        else:
                            new_v_content = description_text
                        new_content = re.sub(
                            r'(<v>)(.*?)(</v>)',
                            r'\1' + new_v_content + r'\3',
                            current_content,
                            flags=re.DOTALL | re.IGNORECASE
                        )
                    else:
                        # Add <v> section at the end
                        new_content = current_content.rstrip() + "\n# Machine Vision\n<v>" + description_text + "</v>\n"
                    
                    # Update text block
                    text_block.clear()
                    text_block.write(new_content)
                    
                    # Save "after" snapshot
                    workspace_setup.save_prompt_snapshot(bpy.context, prefix="after_vision_file")
                    
                    print(f"[Image Description from File] ✓ Appended to <v> tag in text editor")
                    print(f"[Image Description from File] ✅ Description added from: {image_name}")
                    
                except Exception as e:
                    print(f"[Image Description from File] ❌ Callback error: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Register for non-blocking polling
            runcomfy_polling.RunComfyPoller.start_polling(
                deployment_id='server',
                request_id=prompt_id,
                callback=on_description_complete,
                workflow_type='text'
            )
            
            self.report({'INFO'}, f"Generating description from: {image_path.name} (watch progress bar)")
            print(f"[Image Description from File] ⏳ Processing in background...")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Image description failed: {str(e)}")
            print(f"[Image Description from File] ❌ Exception: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}


class WM_OT_GenerateImageDescriptionFromViewport(bpy.types.Operator):
    """Generate description from viewport camera view using machine vision"""
    bl_idname = "style_engine.generate_image_description_from_viewport"
    bl_label = "Describe Viewport"
    bl_description = "Render viewport from active camera, then generate AI description and add to <v> tag"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        import re
        import json
        from pathlib import Path
        from . import runcomfy_deployment
        from . import workspace_setup
        
        # 1. Check if in Server mode (GCS)
        if not runcomfy_deployment.is_server_mode():
            self.report({'ERROR'}, "Image description only works in Server mode (GCS)")
            print("[Viewport Description] ❌ Not in Server mode - feature requires direct ComfyUI connection")
            return {'CANCELLED'}
        
        # 2. Get ai_camera
        prefs = context.preferences.addons['styleengine'].preferences
        camera_name = prefs.camera_name_override
        
        if camera_name not in bpy.data.objects:
            self.report({'ERROR'}, f"{camera_name} not found - run 'Setup Workspace' first")
            print(f"[Viewport Description] ❌ Camera not found: {camera_name}")
            return {'CANCELLED'}
        
        ai_camera = bpy.data.objects[camera_name]
        scene = context.scene
        props = scene.style_engine_props
        
        print(f"[Viewport Description] Rendering viewport from {camera_name}...")
        
        # Save "before" snapshot
        workspace_setup.save_prompt_snapshot(context, prefix="before_vision_viewport")
        
        try:
            # 3. Render viewport screenshot with fast/detailed setting
            temp_dir = workspace_setup.get_temp_directory(context)
            viewport_image_path = temp_dir / "viewport_description.jpg"
            
            # Store original settings
            original_engine = scene.render.engine
            original_format = scene.render.image_settings.file_format
            original_use_compositing = scene.render.use_compositing
            original_resolution_x = scene.render.resolution_x
            original_resolution_y = scene.render.resolution_y
            
            try:
                # Get render quality preference
                render_quality = props.render_quality if hasattr(props, 'render_quality') else 'FAST'
                
                # Configure render engine
                if render_quality == 'DETAILED':
                    scene.render.engine = workspace_setup.get_eevee_engine_name()
                    print(f"[Viewport Description] Using EEVEE (detailed quality)")
                else:
                    scene.render.engine = 'BLENDER_WORKBENCH'
                    print(f"[Viewport Description] Using Workbench (fast preview)")
                
                # Set to 512px max dimension (maintain aspect ratio)
                current_width = scene.render.resolution_x
                current_height = scene.render.resolution_y
                
                if current_width >= current_height:
                    # Landscape or square
                    scale_factor = 512.0 / current_width
                else:
                    # Portrait
                    scale_factor = 512.0 / current_height
                
                scene.render.resolution_x = int(current_width * scale_factor)
                scene.render.resolution_y = int(current_height * scale_factor)
                
                print(f"[Viewport Description] Scaled resolution: {scene.render.resolution_x}x{scene.render.resolution_y} (max 512px)")
                
                # Configure output
                scene.render.image_settings.file_format = 'JPEG'
                scene.render.image_settings.color_mode = 'RGB'
                scene.render.image_settings.quality = 85
                scene.render.use_compositing = False
                scene.render.filepath = str(viewport_image_path.with_suffix(''))
                
                # Render from ai_camera
                print(f"[Viewport Description] Rendering viewport screenshot...")
                workspace_setup.render_from_camera_safe(scene, ai_camera, prefs)
                
                # Verify output
                if not viewport_image_path.exists():
                    self.report({'ERROR'}, "Failed to render viewport screenshot")
                    print(f"[Viewport Description] ❌ Render output not found: {viewport_image_path}")
                    return {'CANCELLED'}
                
                print(f"[Viewport Description] ✓ Rendered: {viewport_image_path.name}")
                
            finally:
                # Restore original settings
                scene.render.engine = original_engine
                scene.render.image_settings.file_format = original_format
                scene.render.use_compositing = original_use_compositing
                scene.render.resolution_x = original_resolution_x
                scene.render.resolution_y = original_resolution_y
            
            # 4. Load TextViewport.json workflow
            addon_dir = Path(__file__).parent
            workflow_file = addon_dir / "workflows" / "Text" / "TextViewport.json"
            
            if not workflow_file.exists():
                self.report({'ERROR'}, "TextViewport.json not found")
                print(f"[Viewport Description] ❌ Workflow not found: {workflow_file}")
                return {'CANCELLED'}
            
            with open(workflow_file, 'r') as f:
                workflow = json.load(f)
            
            print(f"[Viewport Description] ✓ Loaded workflow: {workflow_file.name}")
            
            # 5. Upload image to ComfyUI server
            server_client = runcomfy_deployment.get_server_client()
            
            print(f"[Viewport Description] Uploading viewport screenshot to ComfyUI server...")
            upload_response = server_client.upload_image(str(viewport_image_path), overwrite=True)
            uploaded_filename = upload_response.get("name", "")
            
            if not uploaded_filename:
                self.report({'ERROR'}, "Failed to upload image to server")
                print(f"[Viewport Description] ❌ Upload failed: {upload_response}")
                return {'CANCELLED'}
            
            print(f"[Viewport Description] ✓ Uploaded: {uploaded_filename}")
            
            # 6. Patch node 23 (LoadImage) with the uploaded filename
            if "23" not in workflow:
                self.report({'ERROR'}, "Invalid workflow structure (node 23 missing)")
                print("[Viewport Description] ❌ Node 23 not found in workflow")
                return {'CANCELLED'}
            
            workflow["23"]["inputs"]["image"] = uploaded_filename
            print(f"[Viewport Description] ✓ Patched node 23 with image")
            
            # 7. Submit to ComfyUI server
            print(f"[Viewport Description] Submitting to ComfyUI server...")
            response = server_client.queue_prompt(workflow)
            prompt_id = response['prompt_id']
            print(f"[Viewport Description] ✓ Queued (ID: {prompt_id[:8]}...)")
            
            # Store workflow for progress bar node name lookup
            from . import progress_bar
            progress_bar.set_current_workflow(workflow)
            
            # 8. Start NON-BLOCKING polling with callback
            from . import runcomfy_polling
            
            def on_description_complete(success, result=None, error=None, workflow_type=None):
                """Callback when description completes"""
                print(f"[Viewport Description] Callback triggered: success={success}")
                
                if not success:
                    print(f"[Viewport Description] ❌ Failed: {error}")
                    return
                
                try:
                    # Extract outputs
                    outputs = result.get('outputs', {})
                    
                    # Extract description using helper
                    description_text = _extract_text_from_griptape_output(outputs)
                    
                    if not description_text:
                        print(f"[Viewport Description] ❌ No text output found")
                        return
                    
                    print(f"[Viewport Description] ✓ Generated: {description_text[:100]}...")
                    
                    # APPEND to <v> tag in text editor (not replace!)
                    text_block = bpy.data.texts.get("STYLEENGINE_Prompt")
                    if not text_block:
                        print("[Viewport Description] ❌ Text block not found")
                        return
                    
                    current_content = text_block.as_string()
                    
                    # Check if <v> tag exists
                    v_match = re.search(r'<v>(.*?)</v>', current_content, re.DOTALL | re.IGNORECASE)
                    if v_match:
                        existing_v = v_match.group(1).strip()
                        if existing_v:
                            # Append to existing content with separator
                            new_v_content = existing_v + ". " + description_text
                        else:
                            new_v_content = description_text
                        new_content = re.sub(
                            r'(<v>)(.*?)(</v>)',
                            r'\1' + new_v_content + r'\3',
                            current_content,
                            flags=re.DOTALL | re.IGNORECASE
                        )
                    else:
                        # Add <v> section at the end
                        new_content = current_content.rstrip() + "\n# Machine Vision\n<v>" + description_text + "</v>\n"
                    
                    # Update text block
                    text_block.clear()
                    text_block.write(new_content)
                    
                    # Save "after" snapshot
                    workspace_setup.save_prompt_snapshot(bpy.context, prefix="after_vision_viewport")
                    
                    print(f"[Viewport Description] ✓ Appended to <v> tag in text editor")
                    print(f"[Viewport Description] ✅ Viewport description added!")
                    
                except Exception as e:
                    print(f"[Viewport Description] ❌ Callback error: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Register for non-blocking polling
            runcomfy_polling.RunComfyPoller.start_polling(
                deployment_id='server',
                request_id=prompt_id,
                callback=on_description_complete,
                workflow_type='text'
            )
            
            self.report({'INFO'}, "Generating viewport description... (watch progress bar)")
            print(f"[Viewport Description] ⏳ Processing in background...")
            
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Viewport description failed: {str(e)}")
            print(f"[Viewport Description] ❌ Exception: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}


class WM_OT_GenerateMeshMultiview(bpy.types.Operator):
    """Generate 3D mesh from multiple view images (Coming Soon)"""
    bl_idname = "style_engine.generate_mesh_multiview"
    bl_label = "Generate Mesh (Multiview)"
    bl_description = "Generate 3D mesh from multiple camera angles (Coming Soon)"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        self.report({'INFO'}, "Generate Mesh (Multiview) - Coming Soon")
        return {'FINISHED'}


class WM_OT_GenerateTexturedMeshMultiview(bpy.types.Operator):
    """Generate textured 3D mesh from multiple view images (Coming Soon)"""
    bl_idname = "style_engine.generate_textured_mesh_multiview"
    bl_label = "Generate Textured Mesh (Multiview)"
    bl_description = "Generate textured 3D mesh from multiple camera angles (Coming Soon)"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        self.report({'INFO'}, "Generate Textured Mesh (Multiview) - Coming Soon")
        return {'FINISHED'}


# ----------------------------------------------------------------
# 4. REGISTRATION
# ----------------------------------------------------------------
classes = (
    ObjectGroup,
    StyleEngineProperties,
    WM_OT_AlignAICameraToView,
    WM_OT_BringBackgroundForward,
    WM_OT_SendBackgroundBack,
    # Prompt editor operators removed - now automatic
    WM_OT_AddGroup,
    WM_OT_AssignGroup,
    WM_OT_RenameGroup,
    WM_OT_SelectGroup,
    WM_OT_DeleteGroup,
    WM_OT_ProjectTexture,
    WM_OT_PBRFromProjectedTexture,
    WM_OT_PBRFromText,
    WM_OT_LoadReferenceImage,
    WM_OT_ClearReferenceImage,
    WM_OT_ReloadReferenceImage,
    WM_OT_CancelGeneration,
    WM_OT_RefreshLoraList,
    WM_OT_LoadLoraKeywords,
    WM_OT_TestCloudGeneration,
    WM_OT_RefinePrompt,
    WM_OT_GenerateImageDescription,
    WM_OT_GenerateImageDescriptionFromFile,
    WM_OT_GenerateImageDescriptionFromViewport,
    WM_OT_GenerateMeshMultiview,
    WM_OT_GenerateTexturedMeshMultiview,
    VIEW3D_PT_StyleEngine,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.style_engine_props = bpy.props.PointerProperty(type=StyleEngineProperties)
    
    # Create persistent preview collection for reference image thumbnails
    pcoll = bpy.utils.previews.new()
    preview_collections["ref_images"] = pcoll

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.style_engine_props
    
    # Remove preview collections
    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()

if __name__ == "__main__":
    register()