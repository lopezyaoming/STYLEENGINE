# ================================================================
#    Style Engine - Blender Add-on
#    Main initialization file
#    
#    This is a Blender 4.2+ Extension using blender_manifest.toml
#    No bl_info needed - all metadata is in the manifest file
# ================================================================

import bpy

# Import modules
from . import ui_panel
from . import prefs
from . import workspace_setup

# Import RunComfy modules (no registration needed, just make them available)
from . import runcomfy_client
from . import runcomfy_deployment
from . import runcomfy_polling

# List of modules to register
modules = [
    prefs,
    workspace_setup,
    ui_panel,
]

def register():
    """Register all classes and properties."""
    for module in modules:
        module.register()

def unregister():
    """Unregister all classes and properties."""
    # Cleanup RunComfy poller
    runcomfy_polling.cleanup_poller()
    
    # Unregister modules
    for module in reversed(modules):
        module.unregister()

if __name__ == "__main__":
    register()

