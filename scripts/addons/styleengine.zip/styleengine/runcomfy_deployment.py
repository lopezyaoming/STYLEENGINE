# ================================================================
#    RunComfy Deployment Management
#    Handles deployment creation, validation, and lifecycle
#    NOTE: Server API mode is currently disabled/latent
#    Serverless mode only (with min_instances=1 for equivalent performance)
# ================================================================

import bpy
from .runcomfy_client import RunComfyClient, RunComfyError, RunComfyDeploymentError
from .runcomfy_server_client import ComfyUIServerClient, ServerAPIError


# ----------------------------------------------------------------
# HELPER FUNCTIONS
# ----------------------------------------------------------------

def get_addon_prefs():
    """Get Style Engine addon preferences"""
    return bpy.context.preferences.addons['styleengine'].preferences


def _build_server_url(base_url, prefs):
    """
    Build the final server URL from base URL and port settings.
    
    Priority:
    1. Settings port (gcs_comfy_port) if not default or explicitly set
    2. Port from URL if present
    3. Default port 8188
    
    Args:
        base_url: Base URL from preferences (may or may not include port)
        prefs: Addon preferences object
    
    Returns:
        str: Complete URL with port (e.g., "http://127.0.0.1:8188")
    """
    from urllib.parse import urlparse, urlunparse
    
    default_port = 8188
    settings_port = getattr(prefs, 'gcs_comfy_port', default_port)
    
    # Parse the URL
    parsed = urlparse(base_url)
    
    # Extract host and any existing port from URL
    host = parsed.hostname or parsed.path.split('/')[0].split(':')[0]
    url_port = parsed.port
    
    # Determine final port (settings takes priority over URL port)
    if settings_port != default_port:
        # User explicitly set a custom port in settings
        final_port = settings_port
    elif url_port:
        # URL has a port specified, use it
        final_port = url_port
    else:
        # No port specified anywhere, use default
        final_port = default_port
    
    # Build scheme (default to http if not specified)
    scheme = parsed.scheme if parsed.scheme else 'http'
    
    # Construct the final URL
    final_url = f"{scheme}://{host}:{final_port}"
    
    return final_url


def get_runcomfy_client():
    """
    Create RunComfy client from preferences (for Serverless API).
    
    Returns:
        RunComfyClient: Configured client instance
    
    Raises:
        RunComfyError: If credentials not set
    """
    prefs = get_addon_prefs()
    
    # Get API credentials (prefer env vars if enabled)
    if prefs.use_env_vars:
        import os
        api_token = os.environ.get('RUNCOMFY_API_TOKEN', prefs.runcomfy_api_token)
        user_id = os.environ.get('RUNCOMFY_USER_ID', prefs.runcomfy_user_id)
    else:
        api_token = prefs.runcomfy_api_token
        user_id = prefs.runcomfy_user_id
    
    if not api_token or not user_id:
        raise RunComfyError("RunComfy credentials not configured. Please set API token and User ID in addon preferences.")
    
    return RunComfyClient(api_token, user_id, timeout=prefs.runcomfy_request_timeout)


def get_server_client():
    """
    Create ComfyUI Server client from preferences (for GCS/Server API mode).
    
    Returns:
        ComfyUIServerClient: Configured server client instance
    
    Raises:
        ServerAPIError: If server URL not set
    """
    prefs = get_addon_prefs()
    
    # Get base URL from preferences
    base_url = prefs.gcs_server_url if hasattr(prefs, 'gcs_server_url') and prefs.gcs_server_url else ""
    
    if not base_url:
        raise ServerAPIError("ComfyUI Server URL not configured. Please set the server URL in addon preferences.")
    
    # Build final URL with port handling
    server_url = _build_server_url(base_url, prefs)
    
    return ComfyUIServerClient(server_url, timeout=prefs.runcomfy_request_timeout)


def is_server_mode():
    """
    Check if addon is in GCS/Server mode (direct ComfyUI connection).
    
    Returns:
        bool: True if GCS mode is selected
    """
    prefs = get_addon_prefs()
    # Check if api_backend exists (for compatibility with older versions)
    if hasattr(prefs, 'api_backend'):
        return prefs.api_backend == 'GCS'
    return False


# ----------------------------------------------------------------
# DEPLOYMENT MANAGER
# ----------------------------------------------------------------

class DeploymentManager:
    """Manages RunComfy deployment lifecycle (Serverless and Server modes)"""
    
    @staticmethod
    def ensure_deployment(workflow_type='sdxl'):
        """
        Ensure deployment/server is ready for workflow execution.
        
        In Serverless mode: Ensures deployment exists (auto-creates if needed)
        In Server mode: Validates server connection
        
        Args:
            workflow_type: 'sdxl' or 'ipadapter'
        
        Returns:
            str: deployment_id (serverless) or 'server' (server mode)
        
        Raises:
            RunComfyError/ServerAPIError: If setup cannot be ensured
        """
        if is_server_mode():
            # Server API mode - verify server connection
            print(f"[Server API] Validating ComfyUI server connection...")
            return DeploymentManager._ensure_server_connection()
        else:
            # Serverless mode - ensure deployment exists
            print(f"[Serverless API] Ensuring deployment for {workflow_type}...")
            return DeploymentManager._ensure_serverless_deployment(workflow_type)
    
    @staticmethod
    def _ensure_server_connection():
        """
        Validate connection to ComfyUI server (Server API mode) with detailed diagnostics.
        Auto-launches server if not connected and credentials available.
        
        Returns:
            str: 'server' to indicate server mode
        
        Raises:
            ServerAPIError: If server is not reachable or not healthy
        """
        from .runcomfy_server_manager import RunComfyServerManager, ServerLaunchError, ServerNotReadyError
        
        prefs = get_addon_prefs()
        
        print(f"[Server API] =========================================")
        print(f"[Server API] SERVER CONNECTION VALIDATION")
        print(f"[Server API] =========================================")
        
        # Check if server URL is configured
        if not prefs.comfyui_server_url:
            print(f"[Server API] No server URL configured")
            print(f"[Server API] Attempting to auto-launch a new server...")
            print(f"[Server API]")
            
            # Try auto-launch
            try:
                DeploymentManager._auto_launch_server()
                # Server launched, continue with validation
            except ServerLaunchError as e:
                raise ServerAPIError(
                    f"No server configured and auto-launch failed: {e}. "
                    "Please manually start a server in RunComfy or configure the server URL in preferences."
                )
        
        try:
            server_client = get_server_client()
            server_url = server_client.server_url
            
            print(f"[Server API] Target server: {server_url}")
            print(f"[Server API]")
            
            # Step 1: Check connection
            print(f"[Server API] Step 1: Testing basic connection...")
            connected, conn_status = server_client.check_connection()
            
            if not connected:
                error_msg = conn_status.get('error', 'Unknown connection error')
                print(f"[Server API]")
                print(f"[Server API] ❌ CONNECTION FAILED")
                print(f"[Server API] Error: {error_msg}")
                print(f"[Server API]")
                
                # Try auto-launch if not already tried
                if prefs.runcomfy_server_id:
                    print(f"[Server API] Server exists but not responding.")
                    print(f"[Server API] The server may be stopped or still starting.")
                    print(f"[Server API]")
                    print(f"[Server API] Troubleshooting:")
                    print(f"[Server API]   1. Check server status in RunComfy dashboard")
                    print(f"[Server API]   2. Wait a few minutes if server is starting")
                    print(f"[Server API]   3. Use 'Test Connection' button in preferences to retry")
                    print(f"[Server API]")
                else:
                    print(f"[Server API] Attempting to auto-launch a new server...")
                    print(f"[Server API]")
                    try:
                        DeploymentManager._auto_launch_server()
                        # Retry connection after launch
                        server_client = get_server_client()
                        connected, conn_status = server_client.check_connection()
                        if not connected:
                            raise ServerAPIError("Server launched but still not responding. Please wait and try again.")
                    except ServerLaunchError as e:
                        print(f"[Server API] Auto-launch failed: {e}")
                        print(f"[Server API]")
                        raise ServerAPIError(
                            f"Cannot connect to server and auto-launch failed: {error_msg}. "
                            "Please manually start a server in RunComfy."
                        )
            
            print(f"[Server API] ✓ Basic connection successful")
            print(f"[Server API]")
            
            # Step 2: Check server health
            print(f"[Server API] Step 2: Checking server health...")
            health = server_client.check_server_health()
            
            if not health['healthy']:
                print(f"[Server API]")
                print(f"[Server API] ⚠ SERVER HEALTH WARNING")
                print(f"[Server API] Details: {health['details']}")
                print(f"[Server API]")
                print(f"[Server API] Server is reachable but may not be fully ready.")
                print(f"[Server API] You can try generating, but errors may occur.")
                print(f"[Server API]")
            else:
                print(f"[Server API] ✓ Server health check passed")
                print(f"[Server API]")
            
            # Summary
            print(f"[Server API] =========================================")
            print(f"[Server API] CONNECTION STATUS: ✓ CONNECTED")
            print(f"[Server API] Server URL: {server_url}")
            if health.get('connection', {}).get('queue_info'):
                queue_info = health['connection']['queue_info']
                running = len(queue_info.get('queue_running', []))
                pending = len(queue_info.get('queue_pending', []))
                print(f"[Server API] Queue: {running} running, {pending} pending")
            print(f"[Server API] Health: {'✓ Healthy' if health['healthy'] else '⚠ Warning'}")
            print(f"[Server API] =========================================")
            print(f"[Server API]")
            
            return 'server'
            
        except ServerAPIError as e:
            print(f"[Server API]")
            print(f"[Server API] ❌ SERVER CONNECTION VALIDATION FAILED")
            print(f"[Server API] =========================================")
            raise ServerAPIError(f"Server connection failed: {e}")
        except Exception as e:
            print(f"[Server API]")
            print(f"[Server API] ❌ UNEXPECTED ERROR DURING VALIDATION")
            print(f"[Server API] Error: {e}")
            print(f"[Server API] =========================================")
            import traceback
            traceback.print_exc()
            raise ServerAPIError(f"Unexpected error during server validation: {e}")
    
    @staticmethod
    def _auto_launch_server():
        """
        Automatically launch a new ComfyUI server instance.
        
        Raises:
            ServerLaunchError: If launch fails
        """
        from .runcomfy_server_manager import RunComfyServerManager, ServerLaunchError, ServerNotReadyError
        
        prefs = get_addon_prefs()
        
        # Get API credentials
        if prefs.use_env_vars:
            import os
            api_token = os.environ.get('RUNCOMFY_API_TOKEN', prefs.runcomfy_api_token)
            user_id = os.environ.get('RUNCOMFY_USER_ID', prefs.runcomfy_user_id)
        else:
            api_token = prefs.runcomfy_api_token
            user_id = prefs.runcomfy_user_id
        
        if not api_token or not user_id:
            raise ServerLaunchError(
                "RunComfy credentials not configured. Cannot auto-launch server. "
                "Please configure credentials in addon preferences."
            )
        
        print(f"[Server Manager] Auto-launching new ComfyUI server...")
        
        # Create server manager
        manager = RunComfyServerManager(
            api_token=api_token,
            user_id=user_id
        )
        
        # Create server
        hardware = prefs.runcomfy_hardware_tier
        workflow_id = prefs.runcomfy_workflow_id if prefs.runcomfy_workflow_id else None
        
        server_info = manager.create_server(
            workflow_id=workflow_id,
            hardware_tier=hardware,
            name='Style Engine ComfyUI Server (Auto-launched)'
        )
        
        # Save server info to preferences
        prefs.runcomfy_server_id = server_info['server_id']
        prefs.comfyui_server_url = server_info['server_url']
        prefs.runcomfy_server_status = server_info['status']
        
        print(f"[Server Manager] ✓ Server created: {server_info['server_url']}")
        print(f"[Server Manager] Waiting for server to be ready (this may take a few minutes)...")
        
        # Wait for server to be ready
        try:
            manager.wait_for_server_ready(server_info['server_id'], timeout=300)
            prefs.runcomfy_server_status = 'running'
            print(f"[Server Manager] ✓ Server is ready!")
        except ServerNotReadyError as e:
            prefs.runcomfy_server_status = 'starting'
            print(f"[Server Manager] ⚠ Server created but not yet ready: {e}")
            print(f"[Server Manager] You can wait and try again shortly.")
    
    @staticmethod
    def _ensure_serverless_deployment(workflow_type):
        """
        Ensure deployment exists for workflow type (Serverless mode).
        Hybrid approach: Try provided deployment_id, auto-create if needed.
        
        Args:
            workflow_type: 'sdxl' or 'ipadapter'
        
        Returns:
            str: deployment_id
        
        Raises:
            RunComfyError: If deployment cannot be ensured
        """
        prefs = get_addon_prefs()
        client = get_runcomfy_client()
        
        # Use unified deployment (same for both SDXL and IPAdapter)
        deployment_id = prefs.runcomfy_deployment_id
        workflow_id = prefs.runcomfy_workflow_id
        deployment_name = f"Style Engine - {workflow_type.upper()}"
        
        # Check if workflow_id is set
        if not workflow_id:
            raise RunComfyError(
                f"Workflow ID not configured. "
                "Please set workflow ID in addon preferences."
            )
        
        # Try to use provided deployment_id
        if deployment_id:
            try:
                if DeploymentManager.validate_deployment(client, deployment_id):
                    print(f"[Serverless API] Using existing deployment: {deployment_id[:8]}...")
                    return deployment_id
                else:
                    print(f"[Serverless API] Deployment {deployment_id[:8]} is disabled or invalid")
            except RunComfyDeploymentError:
                print(f"[Serverless API] Deployment {deployment_id[:8]} not found")
        
        # Auto-create deployment
        print(f"[Serverless API] Auto-creating deployment for {workflow_type}...")
        new_deployment = DeploymentManager.create_deployment_for_workflow(
            client=client,
            workflow_id=workflow_id,
            name=deployment_name,
            hardware=prefs.runcomfy_hardware_tier
        )
        
        new_deployment_id = new_deployment['id']
        print(f"[Serverless API] Created deployment: {new_deployment_id[:8]}...")
        
        # Save deployment_id to preferences (unified for both workflows)
        prefs.runcomfy_deployment_id = new_deployment_id
        
        return new_deployment_id
    
    @staticmethod
    def create_deployment_for_workflow(client, workflow_id, name, hardware):
        """
        Create deployment with hardware configuration from preferences.
        
        Args:
            client: RunComfyClient instance
            workflow_id: Workflow ID to deploy
            name: Deployment name
            hardware: Hardware tier (e.g., 'AMPERE_48')
        
        Returns:
            dict: Created deployment details
        """
        prefs = get_addon_prefs()
        
        # Build deployment config
        config = {
            'scaling': {
                'min_instances': prefs.runcomfy_min_instances,
                'max_instances': prefs.runcomfy_max_instances,
                'queue_size': prefs.runcomfy_queue_size,
            },
            'keep_warm_seconds': prefs.runcomfy_keep_warm_seconds,
        }
        
        try:
            deployment = client.create_deployment(
                workflow_id=workflow_id,
                name=name,
                hardware=hardware,
                config=config
            )
            return deployment
        except RunComfyError as e:
            raise RunComfyError(f"Failed to create deployment: {e}")
    
    @staticmethod
    def validate_deployment(client, deployment_id):
        """
        Check if deployment exists and is enabled.
        
        Args:
            client: RunComfyClient instance
            deployment_id: Deployment ID to validate
        
        Returns:
            bool: True if deployment is valid and enabled
        """
        try:
            deployment = client.get_deployment(deployment_id)
            return deployment.get('is_enabled', False)
        except RunComfyDeploymentError:
            return False
    
    @staticmethod
    def list_user_deployments():
        """
        List all deployments for the user.
        
        Returns:
            list: List of deployment dicts
        """
        try:
            client = get_runcomfy_client()
            return client.list_deployments()
        except RunComfyError as e:
            print(f"[RunComfy] Failed to list deployments: {e}")
            return []
    
    @staticmethod
    def get_deployment_info(deployment_id):
        """
        Get deployment information.
        
        Args:
            deployment_id: Deployment ID
        
        Returns:
            dict: Deployment details or None if not found
        """
        try:
            client = get_runcomfy_client()
            return client.get_deployment(deployment_id)
        except RunComfyError as e:
            print(f"[RunComfy] Failed to get deployment info: {e}")
            return None

